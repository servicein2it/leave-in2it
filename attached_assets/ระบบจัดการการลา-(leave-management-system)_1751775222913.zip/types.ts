
import { Timestamp } from './firebase/mock';

export enum Role {
  EMPLOYEE = 'employee',
  ADMIN = 'admin',
}

export enum Gender {
  MALE = 'male',
  FEMALE = 'female',
}

export enum Title {
  NAI = 'nai',       // นาย
  NANG = 'nang',     // นาง
  NANGSAO = 'nangsao', // นางสาว
}

export enum LeaveType {
  SICK = 'sick',
  MATERNITY = 'maternity',
  STERILIZATION = 'sterilization',
  PERSONAL_BUSINESS = 'personalBusiness',
  ANNUAL = 'annual',
  MILITARY = 'military',
  ACCUMULATED = 'accumulated',
}

export enum LeaveStatus {
  PENDING = 'pending',
  APPROVED = 'approved',
  REJECTED = 'rejected',
}

export interface LeaveBalances {
  sickLeave: number;
  maternityLeave: number;
  sterilizationLeave: number;
  personalBusinessLeave: number;
  annualLeave: number;
  militaryLeave: number;
  accumulatedLeave: number;
}

export interface UserData {
  userId: string;
  username: string; // Login username
  password?: string; // User's password
  role: Role;
  leaveBalances: LeaveBalances;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  
  // Detailed employee fields
  title: Title;
  firstName: string;
  lastName: string;
  nickname?: string;
  gender: Gender;
  email?: string;
  mobilePhone?: string;
  profileImageUrl?: string;
  lineUserId?: string;
  position?: string;
  facebook?: string;
  instagram?: string;
  address?: string;
}

export type EmployeeFormData = Omit<UserData, 'userId' | 'role' | 'createdAt' | 'updatedAt'>;


export interface EmployeeSummary {
  userId: string;
  username: string;
  nickname?: string;
  role: Role;
  leaveBalances: LeaveBalances;
  updatedAt: Timestamp;
  title: Title;
  firstName: string;
  lastName: string;
  gender: Gender;
  email?: string;
  mobilePhone?: string;
  profileImageUrl?: string;
  lineUserId?: string;
  position?: string;
  facebook?: string;
  instagram?: string;
  address?: string;
}


export interface LeaveRequest {
  id: string; // Document ID
  userId: string;
  username:string;
  leaveType: LeaveType;
  startDate: string; // 'YYYY-MM-DD'
  endDate: string; // 'YYYY-MM-DD'
  durationDays: number;
  notes: string;
  status: LeaveStatus;
  requestedAt: Timestamp;
  approvedAt?: Timestamp;
  adminNotes?: string;
}

export interface Message {
    type: 'success' | 'error';
    text: string;
}

export interface AIAnalysis {
  summary: string;
  potentialIssues: string[];
  suggestedQuestions: string[];
}

export interface AIDailyBriefing {
  pendingRequestsCount: number;
  urgentItems: string[];
  observations: string[];
  proactiveSuggestion: string;
}

export interface Notification {
  id: string;
  userId: string;
  message: string;
  isRead: boolean;
  createdAt: Timestamp;
  leaveRequestId: string;
}

export type MyProfileFormData = Pick<UserData, 'nickname' | 'profileImageUrl' | 'address' | 'facebook' | 'instagram'>;