
// STEP 1: Get your Firebase configuration from your project settings.
// STEP 2: Replace the placeholder values below with your actual Firebase keys.

// IMPORTANT: Replace these placeholder values with your actual Firebase project configuration.
// You can find this in your Firebase project settings.
// This configuration is for a sample project and will not work for you.
export const firebaseConfig = {
  apiKey: "AIzaSyDJAAxtqqf_t0pTZj3Dy5yqjo8YAF874tY", // Replace with your API Key
  authDomain: "in2it-work-schedule.firebaseapp.com", // Replace with your Auth Domain
  projectId: "in2it-work-schedule", // Replace with your Project ID
  storageBucket: "in2it-work-schedule.firebasestorage.app", // Replace with your Storage Bucket
  messagingSenderId: "100795186172", // Replace with your Messaging Sender ID
  appId: "1:100795186172:web:a2e16d8ced8f8198d5d079" // Replace with your App ID
};

// This check is no longer used as we default to a mock implementation.
export const isFirebaseConfigProvided = false;
