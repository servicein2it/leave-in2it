
import React, { useState, useEffect, useCallback } from 'react';
import { 
  FirebaseApp, initializeApp,
  Auth, getAuth, onAuthStateChanged, User, signOut,
  Firestore, getFirestore, doc, writeBatch, serverTimestamp,
  signInWithUsernameAndPassword,
  collection,
  query,
  where,
  onSnapshot,
  orderBy
} from './firebase/mock';
import { GoogleGenAI, GenerateContentResponse } from '@google/genai';
import { UserData, Role, Message, EmployeeFormData, LeaveRequest, AIAnalysis, LeaveType, Notification, EmployeeSummary, MyProfileFormData } from './types';
import { defaultLeaveBalances, leaveTypeMap } from './constants';
import LoginPage from './components/LoginPage';
import EmployeeDashboard from './components/dashboards/EmployeeDashboard';
import AdminDashboard from './components/dashboards/AdminDashboard';
import LoadingSpinner from './components/ui/LoadingSpinner';
import MessageComponent from './components/ui/Message';
import NotificationsBell from './components/ui/NotificationsBell';
import EmployeeProfilePage from './components/dashboards/EmployeeProfilePage';


// --- Environment-provided variables ---
declare var __app_id: string | undefined;

// Mock Gemini AI client to avoid needing a real API key for this demo.
class MockGoogleGenAI {
  apiKey: string;
  constructor(options: { apiKey: string }) {
    this.apiKey = options.apiKey;
    console.log('Mock GoogleGenAI initialized.');
  }

  get models() {
    return {
      generateContent: async (params: { model: string; contents: string; config?: any }): Promise<GenerateContentResponse> => {
        console.log('Mock AI generating content for prompt...');
        await new Promise(resolve => setTimeout(resolve, 1500));

        let analysis: AIAnalysis;
        
        analysis = {
          summary: "คำขอลาป่วยเนื่องจาก 'ปวดหัว มีไข้' เป็นเหตุผลที่พบได้ทั่วไปและสมเหตุสมผล",
          potentialIssues: [
            "เหตุผลที่ให้มาค่อนข้างสั้น อาจต้องการรายละเอียดเพิ่มเติมหากเป็นการลาป่วยระยะยาว",
            "ไม่มีเอกสารแนบ เช่น ใบรับรองแพทย์ (ซึ่งไม่จำเป็นสำหรับการลาป่วย 1-2 วัน)"
          ],
          suggestedQuestions: [
            "อาการดีขึ้นหรือยัง?",
            "ต้องการความช่วยเหลือเพิ่มเติมหรือไม่?",
            "คาดว่าจะกลับมาทำงานได้เมื่อไหร่?"
          ]
        };
        
        const responseText = JSON.stringify(analysis);
        
        return {
          text: responseText,
        } as unknown as GenerateContentResponse;
      },
    };
  }
}

const App: React.FC = () => {
  const [app, setApp] = useState<FirebaseApp | null>(null);
  const [auth, setAuth] = useState<Auth | null>(null);
  const [db, setDb] = useState<Firestore | null>(null);
  const [aiClient, setAiClient] = useState<MockGoogleGenAI | null>(null);
  
  const [isLoading, setIsLoading] = useState(true);
  const [currentUserData, setCurrentUserData] = useState<UserData | null>(null);
  const [message, setMessage] = useState<Message | null>(null);
  const [loginLoading, setLoginLoading] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [employeeView, setEmployeeView] = useState<'dashboard' | 'profile'>('dashboard');


  const appId = typeof __app_id !== 'undefined' ? __app_id : 'leave-system-dev';

  useEffect(() => {
    console.warn('%cFirebase config not provided. Running in mock mode.', 'color: orange; font-weight: bold;');
    
    const firebaseApp = initializeApp({});
    const firebaseAuth = getAuth(firebaseApp);
    const firestoreDb = getFirestore(firebaseApp);
    const mockAi = new MockGoogleGenAI({ apiKey: 'mock-api-key' });

    setApp(firebaseApp);
    setAuth(firebaseAuth);
    setDb(firestoreDb);
    setAiClient(mockAi);

    const unsubscribeAuth = onAuthStateChanged(firebaseAuth, (user) => {
        if (user) {
          setCurrentUserData(user);
          if (user.role === Role.ADMIN) {
            setEmployeeView('dashboard'); // Reset for admin
          }
        } else {
          setCurrentUserData(null);
        }
        setIsLoading(false);
    });

    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    if (!db || !currentUserData || currentUserData.role === Role.ADMIN) {
        setNotifications([]);
        return;
    }
    const notificationsCollection = collection(db, `artifacts/${appId}/public/data/notifications`);
    const q = query(notificationsCollection, where('userId', '==', currentUserData.userId), orderBy('createdAt', 'desc'));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
        const userNotifications: Notification[] = [];
        snapshot.forEach((doc: any) => {
            userNotifications.push({ id: doc.id, ...doc.data() });
        });
        setNotifications(userNotifications);
    });
    
    return () => unsubscribe();
  }, [db, currentUserData, appId]);

  const handleJsonParse = <T,>(text: string): T => {
    let jsonStr = text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }
    return JSON.parse(jsonStr) as T;
  };

  const handleLogin = useCallback(async (username: string, password?: string) => {
    if (!auth) {
      setMessage({ type: 'error', text: 'ระบบยังไม่พร้อม โปรดลองอีกครั้ง' });
      return;
    }
    setLoginLoading(true);
    setLoginError(null);

    try {
        const { user } = await signInWithUsernameAndPassword(auth, username, password);
        setCurrentUserData(user);
        setMessage({ type: 'success', text: `เข้าสู่ระบบในฐานะ ${user.username} สำเร็จ` });
    } catch(error) {
        console.error("Login error:", error);
        const errorMessage = error instanceof Error ? error.message : 'เกิดข้อผิดพลาดในการเข้าสู่ระบบ';
        setLoginError(errorMessage);
    } finally {
        setLoginLoading(false);
    }
  }, [auth]);

  const handleAnalyzeRequest = useCallback(async (request: LeaveRequest): Promise<AIAnalysis> => {
    if (!aiClient) throw new Error("AI client is not initialized.");
  
    const prompt = `
      Analyze the following leave request from a Human Resources perspective in Thailand.
      Provide a response in JSON format with fields: "summary", "potentialIssues" (array), and "suggestedQuestions" (array).
      Request: ${JSON.stringify({type: leaveTypeMap[request.leaveType], duration: request.durationDays, reason: request.notes})}
    `;
  
    try {
      const response = await aiClient.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: { responseMimeType: "application/json" },
      });
      return handleJsonParse<AIAnalysis>(response.text);
    } catch (e) {
      console.error("Failed to analyze request:", e);
      throw new Error("Could not get an analysis from the AI model.");
    }
  }, [aiClient]);


  const handleSaveEmployee = useCallback(async (employeeData: EmployeeFormData, employeeId?: string) => {
    if (!db) {
        setMessage({ type: 'error', text: 'ระบบยังไม่พร้อม โปรดลองอีกครั้ง' });
        return;
    }
    const isEditing = !!employeeId;
    const userId = isEditing ? employeeId : `mock_user_${Date.now()}`;
    const now = serverTimestamp();
    const batch = writeBatch(db);
    
    if (isEditing) {
        const userDocRef = doc(db, `artifacts/${appId}/users/${userId}/user_data`, userId);
        const summaryDocRef = doc(db, `artifacts/${appId}/public/data/employee_summaries`, userId);
        
        const { password, ...summaryUpdateData } = employeeData;
        const userUpdateData: Partial<UserData> = { ...employeeData, updatedAt: now as any };

        if (!password) {
            delete (userUpdateData as Partial<EmployeeFormData>).password;
        }

        batch.update(userDocRef, userUpdateData);
        batch.update(summaryDocRef, { ...summaryUpdateData, updatedAt: now as any});
    } else {
        const newUser: UserData = {
            ...employeeData,
            userId: userId,
            role: Role.EMPLOYEE,
            leaveBalances: defaultLeaveBalances,
            createdAt: now as any,
            updatedAt: now as any,
        };
        const { password, ...summaryDataPayload } = employeeData;
        const summaryData = {
            ...summaryDataPayload,
            userId: userId, role: Role.EMPLOYEE, leaveBalances: defaultLeaveBalances, updatedAt: now as any,
        };
        const userDocRef = doc(db, `artifacts/${appId}/users/${userId}/user_data`, userId);
        const summaryDocRef = doc(db, `artifacts/${appId}/public/data/employee_summaries`, userId);
        batch.set(userDocRef, newUser);
        batch.set(summaryDocRef, summaryData);
    }

    try {
        await batch.commit();
        setMessage({ type: 'success', text: `บันทึกข้อมูลพนักงาน '${employeeData.username}' สำเร็จ` });
    } catch (error) {
        console.error("Error saving employee:", error);
        setMessage({ type: 'error', text: 'เกิดข้อผิดพลาดในการบันทึกข้อมูลพนักงาน' });
        throw error;
    }
  }, [db, appId]);
  
  const handleResetPassword = useCallback(async (employeeId: string, newPassword: string) => {
      if (!db) return;
      const userDocRef = doc(db, `artifacts/${appId}/users/${employeeId}/user_data`, employeeId);
      const batch = writeBatch(db);
      batch.update(userDocRef, { password: newPassword, updatedAt: serverTimestamp() });
      try {
        await batch.commit();
      } catch (error) {
         console.error("Error resetting password:", error);
         setMessage({ type: 'error', text: 'เกิดข้อผิดพลาดในการรีเซ็ตรหัสผ่าน' });
         throw error;
      }
  }, [db, appId]);

  const handleDeleteEmployee = useCallback(async (employeeId: string) => {
    if (!db) return;
    if (!window.confirm("คุณแน่ใจหรือไม่ว่าต้องการลบพนักงานคนนี้? การกระทำนี้ไม่สามารถย้อนกลับได้")) return;
    try {
        const batch = writeBatch(db);
        const userDocRef = doc(db, `artifacts/${appId}/users/${employeeId}/user_data`, employeeId);
        const summaryDocRef = doc(db, `artifacts/${appId}/public/data/employee_summaries`, employeeId);
        batch.delete(userDocRef);
        batch.delete(summaryDocRef);
        await batch.commit();
        setMessage({ type: 'success', text: 'ลบพนักงานสำเร็จ' });
    } catch (error) {
        console.error("Error deleting employee:", error);
        setMessage({ type: 'error', text: 'เกิดข้อผิดพลาดในการลบพนักงาน' });
        throw error;
    }
  }, [db, appId]);
 
  const handleDeleteLeaveRequest = useCallback(async (requestId: string) => {
    if (!db) return;
    try {
        const batch = writeBatch(db);
        const requestDocRef = doc(db, `artifacts/${appId}/public/data/leave_requests`, requestId);
        batch.delete(requestDocRef);
        await batch.commit();
    } catch (error) {
        console.error("Error deleting leave request:", error);
        setMessage({ type: 'error', text: 'เกิดข้อผิดพลาดในการลบคำขอลา' });
        throw error;
    }
  }, [db, appId]);

  const handleUpdateMyProfile = useCallback(async (profileData: MyProfileFormData) => {
    if (!db || !currentUserData) {
        setMessage({ type: 'error', text: 'ไม่สามารถอัปเดตโปรไฟล์ได้' });
        return;
    }
    
    const userId = currentUserData.userId;
    const batch = writeBatch(db);
    const now = serverTimestamp();

    const userDocRef = doc(db, `artifacts/${appId}/users/${userId}/user_data`, userId);
    const summaryDocRef = doc(db, `artifacts/${appId}/public/data/employee_summaries`, userId);
    
    const updatePayload = { ...profileData, updatedAt: now as any };

    batch.update(userDocRef, updatePayload);
    batch.update(summaryDocRef, updatePayload);

    try {
        await batch.commit();
        setMessage({ type: 'success', text: 'อัปเดตโปรไฟล์สำเร็จแล้ว' });
        setEmployeeView('dashboard'); // Go back to dashboard on success
    } catch (error) {
        console.error("Error updating profile:", error);
        setMessage({ type: 'error', text: 'เกิดข้อผิดพลาดในการอัปเดตโปรไฟล์' });
        throw error;
    }
  }, [db, appId, currentUserData]);

  const handleMarkNotificationsAsRead = useCallback(async (notificationIds: string[]) => {
    if(!db || notificationIds.length === 0) return;
    try {
      const batch = writeBatch(db);
      notificationIds.forEach(id => {
          const notifRef = doc(db, `artifacts/${appId}/public/data/notifications`, id);
          batch.update(notifRef, { isRead: true });
      });
      await batch.commit();
    } catch(error) {
      console.error("Error marking notifications as read:", error);
      setMessage({ type: 'error', text: 'เกิดข้อผิดพลาดในการอัปเดตสถานะการแจ้งเตือน' });
    }
  }, [db, appId]);

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
    setCurrentUserData(null);
    setMessage({ type: 'success', text: 'ออกจากระบบสำเร็จ' });
  };
  
  const handleMessageDismiss = () => {
    setMessage(null);
  };

  useEffect(() => {
    if(message) {
        const timer = setTimeout(() => setMessage(null), 5000);
        return () => clearTimeout(timer);
    }
  }, [message]);
  
  const renderContent = () => {
    if (isLoading) {
      return <div className="flex items-center justify-center h-screen"><LoadingSpinner /></div>;
    }

    if (!currentUserData) {
      return <LoginPage onLogin={handleLogin} isLoading={loginLoading} error={loginError} />;
    }
    
    if (!db || !app) return null;

    const commonProps = { db, appId, setMessage };

    if (currentUserData.role === Role.ADMIN) {
      return <AdminDashboard 
        currentUserData={currentUserData} 
        onSaveEmployee={handleSaveEmployee}
        onDeleteEmployee={handleDeleteEmployee}
        onResetPassword={handleResetPassword}
        onAnalyzeRequest={handleAnalyzeRequest}
        onDeleteLeaveRequest={handleDeleteLeaveRequest}
        {...commonProps} 
       />;
    }
    
    if (employeeView === 'profile') {
        return <EmployeeProfilePage
            currentUserData={currentUserData}
            onUpdateProfile={handleUpdateMyProfile}
            onBack={() => setEmployeeView('dashboard')}
            onError={(text: string) => setMessage({ type: 'error', text })}
        />
    }
    return <EmployeeDashboard currentUserData={currentUserData} {...commonProps} />;
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800">
      <MessageComponent message={message} onDismiss={handleMessageDismiss} />
      {currentUserData && (
        <header className="bg-white shadow-sm sticky top-0 z-30">
            <nav className="container mx-auto px-4 sm:px-6 lg:px-8">
                <div className="flex items-center justify-between h-16">
                    <div className="flex-shrink-0 font-bold text-primary">ระบบจัดการการลา</div>
                    <div className="flex items-center">
                        {currentUserData.role === Role.EMPLOYEE && (
                            <>
                                <NotificationsBell notifications={notifications} onMarkAsRead={handleMarkNotificationsAsRead} />
                                <button 
                                    onClick={() => setEmployeeView('profile')}
                                    className="flex items-center text-sm text-slate-600 mr-4 ml-4 rounded-full p-1 hover:bg-slate-100 transition-colors"
                                    title="แก้ไขโปรไฟล์"
                                >
                                    <img
                                        className="w-8 h-8 rounded-full object-cover mr-2 border border-slate-200"
                                        src={currentUserData.profileImageUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${currentUserData.firstName} ${currentUserData.lastName}`}
                                        alt="profile"
                                    />
                                    สวัสดี, {currentUserData.firstName || currentUserData.username}
                                </button>
                            </>
                        )}
                         {currentUserData.role === Role.ADMIN && (
                            <span className="text-sm text-slate-600 mr-4 ml-4">สวัสดี, {currentUserData.firstName || currentUserData.username}</span>
                         )}
                        <button onClick={handleLogout} className="text-sm font-medium text-slate-500 hover:text-primary-700 transition-colors">ออกจากระบบ</button>
                    </div>
                </div>
            </nav>
        </header>
      )}
      <main className="container mx-auto">
        {renderContent()}
      </main>
    </div>
  );
};

export default App;