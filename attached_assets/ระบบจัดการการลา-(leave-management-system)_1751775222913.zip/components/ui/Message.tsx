
import React from 'react';
import { Message as MessageType } from '../../types';

interface MessageProps {
  message: MessageType | null;
  onDismiss: () => void;
}

const Message: React.FC<MessageProps> = ({ message, onDismiss }) => {
  if (!message) return null;

  const baseClasses = 'fixed top-5 right-5 max-w-sm w-full p-4 rounded-lg shadow-lg flex items-center justify-between z-50';
  const typeClasses = message.type === 'success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';

  return (
    <div className={`${baseClasses} ${typeClasses}`} role="alert">
      <p>{message.text}</p>
      <button onClick={onDismiss} className="ml-4 p-1 rounded-full hover:bg-black/10 transition-colors">
        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      </button>
    </div>
  );
};

export default Message;
