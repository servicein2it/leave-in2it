

import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot, orderBy, Firestore } from '../../firebase/mock';
import { LeaveRequest, UserData } from '../../types';
import { leaveTypeMap, statusMap, statusColorMap } from '../../constants';
import { formatDate } from '../../utils/dateHelpers';
import Card from '../ui/Card';
import LoadingSpinner from '../ui/LoadingSpinner';
import { generatePdfForRequest } from '../../utils/pdfGenerator';
import { DocumentDownloadIcon } from '../ui/Icons';


interface UserLeaveRequestsProps {
  userId: string;
  db: Firestore;
  appId: string;
  currentUserData: UserData;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

const UserLeaveRequests: React.FC<UserLeaveRequestsProps> = ({ userId, db, appId, currentUserData, onSuccess, onError }) => {
  const [requests, setRequests] = useState<LeaveRequest[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [generatingPdfId, setGeneratingPdfId] = useState<string | null>(null);


  useEffect(() => {
    const requestsCollection = collection(db, `artifacts/${appId}/public/data/leave_requests`);
    const q = query(requestsCollection, where("userId", "==", userId), orderBy("requestedAt", "desc"));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const userRequests: LeaveRequest[] = [];
      querySnapshot.forEach((doc:any) => {
        userRequests.push({ id: doc.id, ...doc.data() } as LeaveRequest);
      });
      setRequests(userRequests);
      setIsLoading(false);
    }, (error) => {
        console.error("Error fetching leave requests:", error);
        setIsLoading(false);
    });

    return () => unsubscribe();
  }, [userId, db, appId]);

  const handleGeneratePdf = async (request: LeaveRequest) => {
    setGeneratingPdfId(request.id);
    try {
      await generatePdfForRequest(request, currentUserData);
    } catch (error) {
      console.error("PDF Generation failed", error);
      const errorMessage = error instanceof Error ? error.message : 'ไม่สามารถสร้างไฟล์ได้';
      onError(`เกิดข้อผิดพลาดในการแสดงตัวอย่างเอกสาร: ${errorMessage}`);
    } finally {
      setGeneratingPdfId(null);
    }
  };


  return (
    <Card>
      <h2 className="text-xl font-bold text-slate-800 mb-4">ประวัติการลาของฉัน</h2>
      {isLoading ? <LoadingSpinner /> : (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ประเภท</th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ช่วงวันที่ลา</th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">จำนวนวัน</th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">สถานะ</th>
              <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">เอกสาร</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {requests.length > 0 ? requests.map((req) => (
              <tr key={req.id} className="odd:bg-white even:bg-slate-50">
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900">{leaveTypeMap[req.leaveType]}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500">{`${formatDate(new Date(req.startDate))} - ${formatDate(new Date(req.endDate))}`}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-500 text-center">{req.durationDays}</td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                  <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorMap[req.status]}`}>
                    {statusMap[req.status]}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-center">
                    <button 
                        onClick={() => handleGeneratePdf(req)} 
                        disabled={generatingPdfId === req.id}
                        className="p-1.5 rounded-full text-slate-500 hover:text-primary-700 disabled:opacity-50 disabled:cursor-wait"
                        title="ดูเอกสาร"
                    >
                        {generatingPdfId === req.id ? (
                            <div className="w-5 h-5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                            <DocumentDownloadIcon className="w-5 h-5" />
                        )}
                    </button>
                </td>
              </tr>
            )) : (
              <tr>
                <td colSpan={5} className="px-6 py-4 text-center text-slate-500">ยังไม่มีประวัติการลา</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      )}
    </Card>
  );
};

export default UserLeaveRequests;