

import React from 'react';
import { LeaveBalances, LeaveType, Gender } from '../../types';
import { leaveTypeMap, leaveBalanceKeyToLeaveTypeMap } from '../../constants';
import Card from '../ui/Card';

interface LeaveBalancesDisplayProps {
  balances: LeaveBalances;
  gender: Gender;
}

const LeaveBalancesDisplay: React.FC<LeaveBalancesDisplayProps> = ({ balances, gender }) => {

  const filteredBalanceKeys = (Object.keys(balances) as Array<keyof LeaveBalances>).filter(key => {
    if (gender === Gender.MALE && key === 'maternityLeave') return false;
    if (gender === Gender.FEMALE && key === 'militaryLeave') return false;
    return true;
  });

  return (
    <Card>
        <h2 className="text-xl font-bold text-slate-800 mb-2">จัดการวันลาคงเหลือ</h2>
        <hr className="mb-4" />
        <div className="divide-y divide-slate-200">
        {filteredBalanceKeys.map((key) => (
            <div key={key} className="py-4">
              <p className="text-md text-slate-700">{leaveTypeMap[leaveBalanceKeyToLeaveTypeMap[key]]}</p>
              <p className="text-3xl font-bold text-slate-800 mt-1">{balances[key]}</p>
            </div>
        ))}
        </div>
    </Card>
  );
};

export default LeaveBalancesDisplay;