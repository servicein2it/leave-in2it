

import React, { useState, useMemo, useCallback } from 'react';
import { LeaveBalances, LeaveType, Gender, UserData, LeaveRequest, LeaveStatus } from '../../types';
import { leaveTypeMap, leaveTypeToBalanceKey } from '../../constants';
import { calculateWorkingDays, calculateTotalDays } from '../../utils/dateHelpers';
import { Firestore, collection, addDoc, serverTimestamp, Timestamp } from '../../firebase/mock';
import Card from '../ui/Card';
import { generatePdfForRequest } from '../../utils/pdfGenerator';


interface LeaveRequestFormProps {
  userId: string;
  username: string;
  db: Firestore;
  appId: string;
  balances: LeaveBalances;
  gender: Gender;
  currentUserData: UserData;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
}

const LeaveRequestForm: React.FC<LeaveRequestFormProps> = ({ userId, username, db, appId, balances, gender, currentUserData, onSuccess, onError }) => {
  const [leaveType, setLeaveType] = useState<LeaveType>(LeaveType.SICK);
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const availableLeaveTypes = useMemo(() => {
    return (Object.values(LeaveType)).filter(type => {
      if (gender === Gender.MALE && type === LeaveType.MATERNITY) return false;
      if (gender === Gender.FEMALE && type === LeaveType.MILITARY) return false;
      return true;
    });
  }, [gender]);

  const durationDays = useMemo(() => {
    if (!startDate || !endDate) return 0;
    
    const needsWorkingDays = [LeaveType.SICK, LeaveType.PERSONAL_BUSINESS, LeaveType.ANNUAL].includes(leaveType);
    
    return needsWorkingDays 
      ? calculateWorkingDays(startDate, endDate) 
      : calculateTotalDays(startDate, endDate);
  }, [startDate, endDate, leaveType]);

  const { isBalanceSufficient, requiresBalanceCheck, currentBalance } = useMemo(() => {
    const checkRequired = [LeaveType.SICK, LeaveType.PERSONAL_BUSINESS, LeaveType.ANNUAL, LeaveType.ACCUMULATED].includes(leaveType);
    if (!checkRequired) {
        return { isBalanceSufficient: true, requiresBalanceCheck: false, currentBalance: Infinity };
    }
    const balanceKey = leaveTypeToBalanceKey[leaveType];
    const balance = balances[balanceKey];
    
    // Check if balance is sufficient for the requested duration.
    // If duration is 0, we check if they have any balance to begin with.
    const isSufficient = durationDays > 0 ? balance >= durationDays : balance > 0;

    return { 
        isBalanceSufficient: isSufficient,
        requiresBalanceCheck: true,
        currentBalance: balance,
    };
  }, [leaveType, balances, durationDays]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!leaveType || !startDate || !endDate) {
        onError('กรุณากรอกข้อมูลให้ครบถ้วน');
        return;
    }
    if (new Date(startDate) > new Date(endDate)) {
        onError('วันที่สิ้นสุดต้องไม่มาก่อนวันที่เริ่มต้น');
        return;
    }
    if (durationDays <= 0) {
        onError('จำนวนวันลาต้องมากกว่า 0 วัน');
        return;
    }
    if (requiresBalanceCheck && !isBalanceSufficient) {
        onError(`วัน${leaveTypeMap[leaveType]}คงเหลือไม่เพียงพอ (คงเหลือ ${currentBalance} วัน)`);
        return;
    }
    
    setIsSubmitting(true);
    try {
      const leaveRequestData = {
        userId,
        username,
        leaveType,
        startDate,
        endDate,
        durationDays,
        notes,
        status: 'pending',
        requestedAt: serverTimestamp(),
      };
      
      const requestsCollection = collection(db, `artifacts/${appId}/public/data/leave_requests`);
      const docRef = await addDoc(requestsCollection, leaveRequestData);

      onSuccess('ยื่นคำขอลาสำเร็จแล้ว');

      // --- Generate PDF on submit ---
      const tempRequestForPdf: LeaveRequest = {
        id: docRef.id,
        userId,
        username,
        leaveType,
        startDate,
        endDate,
        durationDays,
        notes,
        status: LeaveStatus.PENDING,
        requestedAt: Timestamp.now(), // Use a fresh timestamp for immediate use
      };

      try {
        await generatePdfForRequest(tempRequestForPdf, currentUserData);
      } catch (pdfError) {
        console.error("PDF generation failed on submit:", pdfError);
        const pdfErrorMessage = pdfError instanceof Error ? pdfError.message : 'ไม่สามารถสร้างไฟล์ได้';
        onError(`ยื่นคำขอสำเร็จ แต่แสดงตัวอย่างเอกสารไม่ได้ (${pdfErrorMessage})`);
      }
      // --- End PDF Generation ---

      // Reset form
      setLeaveType(LeaveType.SICK);
      setStartDate('');
      setEndDate('');
      setNotes('');
    } catch (error) {
      console.error("Error submitting leave request:", error);
      onError('เกิดข้อผิดพลาดในการยื่นคำขอลา');
    } finally {
      setIsSubmitting(false);
    }
  };

  const isSubmitDisabled = isSubmitting || !startDate || !endDate || durationDays <= 0 || (requiresBalanceCheck && !isBalanceSufficient);
  const inputClasses = "mt-1 block w-full border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm";

  return (
    <Card>
      <h2 className="text-xl font-bold text-slate-800 mb-6">ยื่นคำขอลา</h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
          <div>
            <label htmlFor="leaveType" className="block text-sm font-medium text-slate-700">ประเภทการลา</label>
            <select id="leaveType" value={leaveType} onChange={(e) => setLeaveType(e.target.value as LeaveType)} className={inputClasses}>
              {availableLeaveTypes.map(type => (
                <option key={type} value={type}>{leaveTypeMap[type]}</option>
              ))}
            </select>
          </div>
           {durationDays > 0 && (
            <div className="md:pt-7">
                <div className="text-sm text-slate-600 bg-slate-100 p-3 rounded-md flex items-center justify-center h-full">
                    <strong>จำนวนวันลาทั้งหมด:</strong>
                    <span className="ml-2 text-lg font-bold text-primary">{durationDays}</span>
                    <span className="ml-1.5">วัน</span>
                </div>
            </div>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-6">
          <div>
            <label htmlFor="startDate" className="block text-sm font-medium text-slate-700">วันที่เริ่มต้น</label>
            <input type="date" id="startDate" value={startDate} onChange={(e) => setStartDate(e.target.value)} className={inputClasses} />
          </div>
          <div>
            <label htmlFor="endDate" className="block text-sm font-medium text-slate-700">วันที่สิ้นสุด</label>
            <input type="date" id="endDate" value={endDate} min={startDate} onChange={(e) => setEndDate(e.target.value)} className={inputClasses} />
          </div>
        </div>
        
        <div>
          <label htmlFor="notes" className="block text-sm font-medium text-slate-700">เหตุผล/หมายเหตุ</label>
          <textarea id="notes" value={notes} onChange={(e) => setNotes(e.target.value)} rows={4} className={inputClasses} placeholder="ระบุเหตุผลการลา..."></textarea>
        </div>

        {requiresBalanceCheck && !isBalanceSufficient && (
          <p className="text-sm text-center text-red-500 bg-red-50 p-3 rounded-md">
            {currentBalance > 0 
              ? `ยอดวัน${leaveTypeMap[leaveType]}คงเหลือไม่เพียงพอ (ต้องการ ${durationDays} วัน, คงเหลือ ${currentBalance} วัน)`
              : `คุณไม่มียอด${leaveTypeMap[leaveType]}คงเหลือ`}
          </p>
        )}
        
        <button type="submit" disabled={isSubmitDisabled} className="w-full bg-primary text-white font-semibold py-3 px-4 rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors disabled:bg-slate-400 disabled:cursor-not-allowed text-base">
          {isSubmitting ? 'กำลังส่ง...' : 'ส่งคำขอ'}
        </button>
      </form>
    </Card>
  );
};

export default LeaveRequestForm;