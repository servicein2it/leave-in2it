


import React from 'react';
import { UserData, Message } from '../../types';
import LeaveBalancesDisplay from '../leave/LeaveBalancesDisplay';
import LeaveRequestForm from '../leave/LeaveRequestForm';
import UserLeaveRequests from '../leave/UserLeaveRequests';
import { Firestore } from 'firebase/firestore';

interface EmployeeDashboardProps {
  currentUserData: UserData;
  db: Firestore;
  appId: string;
  setMessage: (message: Message | null) => void;
}

const EmployeeDashboard: React.FC<EmployeeDashboardProps> = ({ currentUserData, db, appId, setMessage }) => {
  const handleSuccess = (text: string) => setMessage({ type: 'success', text });
  const handleError = (text: string) => setMessage({ type: 'error', text });

  return (
    <div className="p-4 md:p-8 space-y-6">
      <h1 className="text-3xl font-bold text-slate-800">แดชบอร์ดพนักงาน</h1>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <LeaveRequestForm 
            userId={currentUserData.userId} 
            username={currentUserData.username}
            db={db}
            appId={appId}
            balances={currentUserData.leaveBalances}
            gender={currentUserData.gender}
            currentUserData={currentUserData}
            onSuccess={handleSuccess}
            onError={handleError}
          />
          <UserLeaveRequests 
            userId={currentUserData.userId} 
            db={db}
            appId={appId}
            currentUserData={currentUserData}
            onSuccess={handleSuccess}
            onError={handleError}
          />
        </div>
        <div className="lg:col-span-1">
          <LeaveBalancesDisplay 
            balances={currentUserData.leaveBalances}
            gender={currentUserData.gender}
          />
        </div>
      </div>
    </div>
  );
};

export default EmployeeDashboard;
