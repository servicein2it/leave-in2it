

import React, { useState, useEffect, useCallback } from 'react';
import { UserData, Message, EmployeeSummary, LeaveRequest, AIAnalysis, EmployeeFormData } from '../../types';
import AllLeaveRequests from '../admin/AllLeaveRequests';
import EmployeeManagementPage from '../admin/EmployeeManagementPage';
import { Firestore, collection, query, onSnapshot, orderBy } from '../../firebase/mock';
import Card from '../ui/Card';
import { ArrowRightCircleIcon, UserGroupIcon } from '../ui/Icons';
import EmployeeCardGrid from '../admin/EmployeeCardGrid';

interface AdminDashboardProps {
  currentUserData: UserData;
  db: Firestore;
  appId: string;
  setMessage: (message: Message | null) => void;
  onSaveEmployee: (employeeData: EmployeeFormData, employeeId?: string) => Promise<void>;
  onDeleteEmployee: (employeeId: string) => Promise<void>;
  onResetPassword: (employeeId: string, newPassword: string) => Promise<void>;
  onAnalyzeRequest: (request: LeaveRequest) => Promise<AIAnalysis>;
  onDeleteLeaveRequest: (requestId: string) => Promise<void>;
}

const AdminDashboard: React.FC<AdminDashboardProps> = (props) => {
  const { 
    currentUserData, db, appId, setMessage, onSaveEmployee, 
    onDeleteEmployee, onResetPassword, onAnalyzeRequest, onDeleteLeaveRequest
  } = props;
  
  const [view, setView] = useState<'dashboard' | 'employees'>('dashboard');
  const [allEmployees, setAllEmployees] = useState<EmployeeSummary[]>([]);
  const [isLoadingEmployees, setIsLoadingEmployees] = useState(true);
  
  const [allLeaveRequests, setAllLeaveRequests] = useState<LeaveRequest[]>([]);
  const [isLoadingRequests, setIsLoadingRequests] = useState(true);
  
  const [viewingHistoryFor, setViewingHistoryFor] = useState<EmployeeSummary | null>(null);

  const handleSuccess = (text: string) => setMessage({ type: 'success', text });
  const handleError = (text: string) => setMessage({ type: 'error', text });

  useEffect(() => {
    const summariesCollection = collection(db, `artifacts/${appId}/public/data/employee_summaries`);
    const q = query(summariesCollection, orderBy("username"));
    const unsubscribeEmployees = onSnapshot(q, (snapshot) => {
      const employees: EmployeeSummary[] = [];
      snapshot.forEach((doc: any) => {
        if (doc.data().role !== 'admin') employees.push({ ...doc.data() } as EmployeeSummary);
      });
      setAllEmployees(employees);
      setIsLoadingEmployees(false);
    }, (error) => {
      console.error("Error fetching employees:", error);
      handleError("เกิดข้อผิดพลาดในการโหลดข้อมูลพนักงาน");
      setIsLoadingEmployees(false);
    });

    const requestsCollection = collection(db, `artifacts/${appId}/public/data/leave_requests`);
    const qRequests = query(requestsCollection, orderBy("requestedAt", "desc"));
    const unsubscribeRequests = onSnapshot(qRequests, (snapshot) => {
      const requests: LeaveRequest[] = [];
      snapshot.forEach((doc: any) => {
        requests.push({ id: doc.id, ...doc.data() } as LeaveRequest);
      });
      setAllLeaveRequests(requests);
      setIsLoadingRequests(false);
    }, (error) => {
      console.error("Error fetching leave requests:", error);
      handleError("เกิดข้อผิดพลาดในการโหลดคำขอลา");
      setIsLoadingRequests(false);
    });

    return () => {
      unsubscribeEmployees();
      unsubscribeRequests();
    };
  }, [db, appId]);
  
  if (view === 'employees') {
    return <EmployeeManagementPage
        db={db}
        appId={appId}
        onSaveEmployee={onSaveEmployee}
        onDeleteEmployee={onDeleteEmployee}
        onResetPassword={onResetPassword}
        onSuccess={handleSuccess}
        onError={handleError}
        onBack={() => setView('dashboard')}
    />;
  }

  const commonLeaveRequestProps = {
    db,
    appId,
    employees: allEmployees,
    onSuccess: handleSuccess,
    onError: handleError,
    onAnalyzeRequest,
    onDeleteRequest: onDeleteLeaveRequest,
  };

  if (viewingHistoryFor) {
    return (
      <div className="p-4 md:p-8 space-y-6">
        <AllLeaveRequests
          {...commonLeaveRequestProps}
          requests={allLeaveRequests}
          isLoading={isLoadingRequests}
          filterByEmployeeId={viewingHistoryFor.userId}
          filteredEmployeeName={`ประวัติการลาของ: ${viewingHistoryFor.firstName} ${viewingHistoryFor.lastName}`}
          onClearFilter={() => setViewingHistoryFor(null)}
        />
      </div>
    );
  }

  return (
    <div className="p-4 md:p-8 space-y-6">
      <h1 className="text-3xl font-bold text-slate-800">แดชบอร์ดผู้ดูแลระบบ</h1>
      <div className="grid grid-cols-1 xl:grid-cols-1 gap-6 items-start">
        <Card 
          className="group cursor-pointer transition-all duration-200 hover:bg-primary-50 hover:shadow-lg hover:border-primary-200 border border-transparent"
          onClick={() => setView('employees')}
        >
          <div className="flex justify-between items-center">
            <div className='flex items-center'>
              <div className="bg-primary-100 p-3 rounded-lg mr-4">
                  <UserGroupIcon className="w-6 h-6 text-primary-700" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-800">จัดการพนักงาน</h2>
                <p className="text-slate-500">เพิ่ม, แก้ไข, หรือลบข้อมูลพนักงานในระบบ</p>
              </div>
            </div>
            <ArrowRightCircleIcon className="w-8 h-8 text-slate-300 group-hover:text-primary transition-colors" />
          </div>
        </Card>

        <EmployeeCardGrid employees={allEmployees} onSelectEmployee={setViewingHistoryFor} />

        <AllLeaveRequests 
          {...commonLeaveRequestProps}
          requests={allLeaveRequests}
          isLoading={isLoadingRequests}
        />
      </div>
    </div>
  );
};

export default AdminDashboard;