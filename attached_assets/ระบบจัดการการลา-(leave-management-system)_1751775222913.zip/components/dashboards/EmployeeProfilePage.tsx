

import React, { useState } from 'react';
import { UserData, MyProfileFormData, Gender } from '../../types';
import Card from '../ui/Card';
import { PencilIcon, MaleIcon, FemaleIcon } from '../ui/Icons';

interface EmployeeProfilePageProps {
    currentUserData: UserData;
    onUpdateProfile: (profileData: MyProfileFormData) => Promise<void>;
    onBack: () => void;
    onError: (message: string) => void;
}

const EmployeeProfilePage: React.FC<EmployeeProfilePageProps> = ({ currentUserData, onUpdateProfile, onBack, onError }) => {
    const [formData, setFormData] = useState<MyProfileFormData>({
        nickname: currentUserData.nickname || '',
        profileImageUrl: currentUserData.profileImageUrl || '',
        address: currentUserData.address || '',
        facebook: currentUserData.facebook || '',
        instagram: currentUserData.instagram || '',
    });
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        if (file.size > 2 * 1024 * 1024) { // 2MB limit
            onError("ขนาดไฟล์รูปภาพต้องไม่เกิน 2MB");
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            setFormData(prev => ({
                ...prev,
                profileImageUrl: reader.result as string,
            }));
        };
        reader.readAsDataURL(file);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);
        try {
            await onUpdateProfile(formData);
            // onBack is called inside App.tsx on success
        } catch (error) {
            // error is handled in App.tsx
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="p-4 md:p-8 space-y-6 max-w-4xl mx-auto">
            <div className="flex items-center">
                <button onClick={onBack} className="bg-slate-200 text-slate-800 py-2 px-4 rounded-md hover:bg-slate-300 transition-colors mr-4">
                    &larr; กลับไปแดชบอร์ด
                </button>
                <h1 className="text-3xl font-bold text-slate-800">โปรไฟล์ของฉัน</h1>
            </div>

            <form onSubmit={handleSubmit}>
                <Card className="p-0">
                     <div className="p-6 space-y-8">
                        {/* Profile Picture Upload */}
                        <div className="flex justify-center">
                            <div className="relative">
                                <label htmlFor="photoUpload" className="cursor-pointer group">
                                    <img
                                        src={formData.profileImageUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${currentUserData.firstName} ${currentUserData.lastName}&backgroundColor=0284c7&textColor=ffffff&fontSize=40`}
                                        alt="Profile"
                                        className="w-32 h-32 rounded-full object-cover border-4 border-white shadow-xl"
                                    />
                                    <div className="absolute inset-0 rounded-full bg-black bg-opacity-0 group-hover:bg-opacity-40 flex items-center justify-center transition-opacity duration-300">
                                        <PencilIcon className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                                    </div>
                                </label>
                                <input
                                    id="photoUpload"
                                    type="file"
                                    accept="image/png, image/jpeg, image/webp"
                                    className="hidden"
                                    onChange={handlePhotoChange}
                                />
                            </div>
                        </div>

                        {/* Read-only Section */}
                         <Section title="ข้อมูลส่วนตัว (ไม่สามารถแก้ไขได้)">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <ReadOnlyField label="ชื่อ" value={`${currentUserData.firstName} ${currentUserData.lastName}`} />
                                <ReadOnlyField 
                                    label="เพศ" 
                                    value={currentUserData.gender === Gender.MALE ? 'ชาย' : 'หญิง'} 
                                    icon={currentUserData.gender === Gender.MALE 
                                        ? <MaleIcon className="w-5 h-5 text-blue-500" />
                                        : <FemaleIcon className="w-5 h-5 text-pink-500" />
                                    }
                                />
                                <ReadOnlyField label="ตำแหน่ง" value={currentUserData.position} />
                                <ReadOnlyField label="Email" value={currentUserData.email} />
                                <ReadOnlyField label="เบอร์โทรศัพท์" value={currentUserData.mobilePhone} />
                            </div>
                        </Section>

                        {/* Editable Section */}
                        <Section title="ข้อมูลที่สามารถแก้ไขได้">
                            <div className="space-y-4">
                                <EditableField
                                    label="ชื่อเล่น"
                                    name="nickname"
                                    value={formData.nickname}
                                    onChange={handleChange}
                                />
                                <EditableField
                                    label="ที่อยู่"
                                    name="address"
                                    value={formData.address}
                                    onChange={handleChange}
                                    isTextArea
                                />
                                <EditableField
                                    label="Facebook Profile URL"
                                    name="facebook"
                                    value={formData.facebook}
                                    onChange={handleChange}
                                    placeholder="https://..."
                                />
                                 <EditableField
                                    label="Instagram Profile URL"
                                    name="instagram"
                                    value={formData.instagram}
                                    onChange={handleChange}
                                    placeholder="https://..."
                                />
                            </div>
                        </Section>
                    </div>

                    <div className="flex justify-end p-6 bg-slate-50 border-t border-slate-200">
                        <button type="submit" disabled={isSubmitting} className="bg-primary text-white font-semibold py-2 px-6 rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors disabled:bg-slate-400">
                            {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกการเปลี่ยนแปลง'}
                        </button>
                    </div>
                </Card>
            </form>
        </div>
    );
};

const Section: React.FC<{title: string, children: React.ReactNode}> = ({ title, children }) => (
    <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-700 border-b border-slate-200 pb-2">{title}</h3>
        <div className="pt-2">
            {children}
        </div>
    </div>
);

const ReadOnlyField: React.FC<{label: string, value?: string, icon?: React.ReactNode}> = ({label, value, icon}) => (
    <div>
        <label className="block text-sm font-medium text-slate-500">{label}</label>
        <p className="mt-1 text-sm text-slate-800 font-medium bg-slate-100 p-2 rounded-md min-h-[42px] flex items-center">
            {icon && <span className="mr-2">{icon}</span>}
            {value || '-'}
        </p>
    </div>
);


const EditableField: React.FC<{
    label: string;
    name: keyof MyProfileFormData;
    value?: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    placeholder?: string;
    isTextArea?: boolean;
}> = ({ label, name, value, onChange, placeholder, isTextArea = false }) => {
    const commonProps = {
        id: name,
        name: name,
        value: value,
        onChange: onChange,
        placeholder: placeholder || label,
        className: "mt-1 block w-full border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm transition-shadow"
    };

    return (
        <div>
            <label htmlFor={name} className="block text-sm font-medium text-slate-700">
                {label}
            </label>
            {isTextArea ? (
                <textarea {...commonProps} rows={3}></textarea>
            ) : (
                <input type="text" {...commonProps} />
            )}
        </div>
    );
};


export default EmployeeProfilePage;
