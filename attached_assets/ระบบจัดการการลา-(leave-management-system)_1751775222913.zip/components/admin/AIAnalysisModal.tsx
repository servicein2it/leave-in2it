
import React from 'react';
import Card from '../ui/Card';
import { AIAnalysis } from '../../types';
import LoadingSpinner from '../ui/LoadingSpinner';
import { SparklesIcon } from '../ui/Icons';

interface AIAnalysisModalProps {
    isOpen: boolean;
    onClose: () => void;
    analysis: AIAnalysis | null;
    isLoading: boolean;
    error: string | null;
}

const AIAnalysisModal: React.FC<AIAnalysisModalProps> = ({ isOpen, onClose, analysis, isLoading, error }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="relative w-full max-w-lg" onClick={e => e.stopPropagation()}>
                <Card className="max-h-[80vh] overflow-y-auto">
                    <div className="flex justify-between items-start mb-4">
                        <div className="flex items-center">
                            <div className="bg-purple-100 text-purple-700 p-2 rounded-lg mr-4">
                               <SparklesIcon className="w-6 h-6" />
                            </div>
                            <div>
                                <h2 className="text-xl font-bold text-slate-800">AI-Powered Analysis</h2>
                                <p className="text-sm text-slate-500">Powered by Google Gemini</p>
                            </div>
                        </div>
                        <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:bg-slate-200 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>

                    <div className="min-h-[250px]">
                        {isLoading && <LoadingSpinner />}
                        
                        {error && !isLoading && (
                            <div className="text-center p-4 bg-red-50 text-red-700 rounded-lg">
                                <h3 className="font-bold">เกิดข้อผิดพลาด</h3>
                                <p className="text-sm">{error}</p>
                            </div>
                        )}

                        {analysis && !isLoading && (
                            <div className="space-y-4 text-sm">
                                <AnalysisSection title="สรุปคำขอ">
                                    <p className="text-slate-700">{analysis.summary}</p>
                                </AnalysisSection>
                                
                                <AnalysisSection title="ข้อควรพิจารณา">
                                    {analysis.potentialIssues.length > 0 ? (
                                        <ul className="list-disc list-inside space-y-1 text-slate-700">
                                            {analysis.potentialIssues.map((issue, index) => <li key={index}>{issue}</li>)}
                                        </ul>
                                    ) : (
                                        <p className="text-slate-500 italic">ไม่พบประเด็นที่น่ากังวล</p>
                                    )}
                                </AnalysisSection>

                                <AnalysisSection title="คำถามที่แนะนำ">
                                     {analysis.suggestedQuestions.length > 0 ? (
                                        <ul className="list-disc list-inside space-y-1 text-slate-700">
                                            {analysis.suggestedQuestions.map((q, index) => <li key={index}>{q}</li>)}
                                        </ul>
                                     ) : (
                                        <p className="text-slate-500 italic">ไม่มีคำถามที่แนะนำ</p>
                                     )}
                                </AnalysisSection>
                            </div>
                        )}
                    </div>
                </Card>
            </div>
        </div>
    );
};

const AnalysisSection: React.FC<{title: string; children: React.ReactNode}> = ({ title, children }) => (
    <div>
        <h3 className="font-bold text-slate-800 mb-2">{title}</h3>
        <div className="bg-slate-50 p-3 rounded-md border border-slate-200">
           {children}
        </div>
    </div>
);


export default AIAnalysisModal;
