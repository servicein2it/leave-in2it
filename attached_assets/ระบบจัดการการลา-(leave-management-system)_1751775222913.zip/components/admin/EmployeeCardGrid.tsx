
import React from 'react';
import { EmployeeSummary } from '../../types';
import Card from '../ui/Card';
import { DocumentTextIcon } from '../ui/Icons';

interface EmployeeCardGridProps {
  employees: EmployeeSummary[];
  onSelectEmployee: (employee: EmployeeSummary) => void;
}

const EmployeeCardGrid: React.FC<EmployeeCardGridProps> = ({ employees, onSelectEmployee }) => {
  if (employees.length === 0) {
    return null; // Don't render if no employees
  }
  return (
    <Card>
      <h2 className="text-xl font-bold text-slate-800 mb-4">ภาพรวมพนักงาน</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {employees.map((employee) => (
          <div
            key={employee.userId}
            onClick={() => onSelectEmployee(employee)}
            className="group relative bg-slate-50 p-4 rounded-lg cursor-pointer transition-all duration-300 hover:shadow-md hover:bg-white hover:scale-105"
          >
            <div className="flex flex-col items-center text-center">
              <img
                className="w-20 h-20 rounded-full object-cover mb-3 shadow-sm"
                src={employee.profileImageUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${employee.firstName} ${employee.lastName}`}
                alt={`${employee.firstName} ${employee.lastName}`}
              />
              <p className="font-semibold text-slate-800 text-sm truncate w-full">{employee.nickname || `${employee.firstName} ${employee.lastName}`}</p>
              <p className="text-xs text-slate-500 truncate w-full">{employee.position || 'N/A'}</p>
            </div>
            <div className="absolute inset-0 bg-primary/80 rounded-lg flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <DocumentTextIcon className="w-8 h-8 text-white mb-1" />
                <p className="text-white text-xs font-semibold">ดูประวัติการลา</p>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default EmployeeCardGrid;
