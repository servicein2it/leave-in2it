
import React, { useState, useMemo } from 'react';
import { collection, query, onSnapshot, orderBy, doc, runTransaction, serverTimestamp, Firestore } from '../../firebase/mock';
import { LeaveRequest, LeaveStatus, UserData, LeaveType, LeaveBalances, AIAnalysis, Notification, EmployeeSummary } from '../../types';
import { leaveTypeMap, statusMap, statusColorMap, leaveTypeToBalanceKey } from '../../constants';
import { formatDate } from '../../utils/dateHelpers';
import Card from '../ui/Card';
import LoadingSpinner from '../ui/LoadingSpinner';
import AIAnalysisModal from './AIAnalysisModal';
import { SparklesIcon, TrashIcon, DocumentDownloadIcon } from '../ui/Icons';
import { generatePdfForRequest } from '../../utils/pdfGenerator';

interface AllLeaveRequestsProps {
  db: Firestore;
  appId: string;
  requests: LeaveRequest[];
  employees: EmployeeSummary[];
  isLoading: boolean;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
  onAnalyzeRequest: (request: LeaveRequest) => Promise<AIAnalysis>;
  onDeleteRequest: (requestId: string) => Promise<void>;
  filterByEmployeeId?: string | null;
  filteredEmployeeName?: string | null;
  onClearFilter?: () => void;
}


const AllLeaveRequests: React.FC<AllLeaveRequestsProps> = (props) => {
  const { 
    db, appId, requests, employees, isLoading, 
    onSuccess, onError, onAnalyzeRequest, onDeleteRequest,
    filterByEmployeeId, filteredEmployeeName, onClearFilter 
  } = props;
  
  const [isProcessing, setIsProcessing] = useState<string | null>(null);
  const [generatingPdfId, setGeneratingPdfId] = useState<string | null>(null);

  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisModalOpen, setAnalysisModalOpen] = useState(false);
  const [currentAnalysis, setCurrentAnalysis] = useState<AIAnalysis | null>(null);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [analyzingRequestId, setAnalyzingRequestId] = useState<string | null>(null);

  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth()); // 0-11
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());

  const handleAnalyzeClick = async (request: LeaveRequest) => {
    setIsAnalyzing(true);
    setAnalyzingRequestId(request.id);
    setAnalysisError(null);
    setCurrentAnalysis(null);
    setAnalysisModalOpen(true);
    try {
      const result = await onAnalyzeRequest(request);
      setCurrentAnalysis(result);
    } catch (e) {
      const errorMessage = e instanceof Error ? e.message : 'An unknown error occurred during analysis.';
      setAnalysisError(errorMessage);
      onError('เกิดข้อผิดพลาดในการวิเคราะห์ด้วย AI');
    } finally {
      setIsAnalyzing(false);
    }
  };
  
  const handleDelete = async (requestId: string) => {
    if (window.confirm("คุณแน่ใจหรือไม่ว่าต้องการลบประวัติการลานี้?")) {
        try {
            await onDeleteRequest(requestId);
            onSuccess("ลบประวัติการลาสำเร็จ");
        } catch(e) {
            // Error message is handled in App.tsx
        }
    }
  };

  const handleGeneratePdf = async (request: LeaveRequest) => {
    setGeneratingPdfId(request.id);
    const employee = employees.find(e => e.userId === request.userId);
    if (!employee) {
      onError("ไม่พบข้อมูลพนักงานสำหรับสร้างเอกสาร");
      setGeneratingPdfId(null);
      return;
    }
    try {
      await generatePdfForRequest(request, employee);
    } catch (error) {
      console.error("PDF Generation failed", error);
      const errorMessage = error instanceof Error ? error.message : 'ไม่สามารถสร้างไฟล์ได้';
      onError(`เกิดข้อผิดพลาดในการแสดงตัวอย่างเอกสาร: ${errorMessage}`);
    } finally {
      setGeneratingPdfId(null);
    }
  };

  const handleUpdateRequest = async (request: LeaveRequest, newStatus: LeaveStatus.APPROVED | LeaveStatus.REJECTED) => {
    setIsProcessing(request.id);
    
    const requestDocRef = doc(db, `artifacts/${appId}/public/data/leave_requests`, request.id);
    const userDocRef = doc(db, `artifacts/${appId}/users/${request.userId}/user_data`, request.userId);
    const summaryDocRef = doc(db, `artifacts/${appId}/public/data/employee_summaries`, request.userId);

    try {
      await runTransaction(db, async (transaction) => {
        if (newStatus === LeaveStatus.APPROVED) {
          const userDoc = await transaction.get(userDocRef);
          if (!userDoc.exists()) {
            throw new Error("User document does not exist!");
          }
          const userData = userDoc.data() as UserData;
          const currentBalances = userData.leaveBalances;
          const leaveTypeKey = leaveTypeToBalanceKey[request.leaveType];
          
          if (leaveTypeKey && currentBalances[leaveTypeKey] < request.durationDays) {
              throw new Error("Insufficient leave balance for approval.");
          }
          
          const newBalances: LeaveBalances = { ...currentBalances };
          if(leaveTypeKey) {
            newBalances[leaveTypeKey] -= request.durationDays;
          }
          
          transaction.update(userDocRef, { leaveBalances: newBalances, updatedAt: serverTimestamp() });
          transaction.update(summaryDocRef, { leaveBalances: newBalances, updatedAt: serverTimestamp() });
        }
        
        transaction.update(requestDocRef, {
            status: newStatus,
            approvedAt: serverTimestamp(),
        });
        
        const notificationId = `notif_${Date.now()}`;
        const notificationRef = doc(db, `artifacts/${appId}/public/data/notifications`, notificationId);
        const statusText = newStatus === LeaveStatus.APPROVED ? 'อนุมัติแล้ว' : 'ปฏิเสธแล้ว';
        const notificationMessage = `คำขอ${leaveTypeMap[request.leaveType]}ของคุณได้รับการ${statusText}`;

        transaction.set(notificationRef, {
            id: notificationId,
            userId: request.userId,
            message: notificationMessage,
            isRead: false,
            createdAt: serverTimestamp(),
            leaveRequestId: request.id,
        });
      });

      onSuccess(`คำขอของ ${request.username} ได้รับการ${newStatus === LeaveStatus.APPROVED ? 'อนุมัติ' : 'ปฏิเสธ'}แล้ว`);
    } catch (error) {
      console.error("Transaction failed: ", error);
      onError(error instanceof Error ? error.message : "เกิดข้อผิดพลาดในการอัปเดตคำขอ");
    } finally {
        setIsProcessing(null);
    }
  };
  
  const availableYears = useMemo(() => {
    const years = new Set(requests.map(r => new Date(r.startDate).getFullYear()));
    years.add(new Date().getFullYear());
    return Array.from(years).filter(y => !isNaN(y)).sort((a, b) => b - a);
  }, [requests]);
  
  const months = useMemo(() => [
      'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 
      'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'
  ], []);

  const filteredRequests = useMemo(() => {
    if (filterByEmployeeId) {
        return requests.filter(r => r.userId === filterByEmployeeId);
    }
    
    return requests.filter(r => {
        try {
            const startDate = new Date(r.startDate);
            if (isNaN(startDate.getTime())) return false; 
            return startDate.getMonth() === selectedMonth && startDate.getFullYear() === selectedYear;
        } catch(e) {
            return false;
        }
    });
  }, [requests, filterByEmployeeId, selectedMonth, selectedYear]);

  const title = filteredEmployeeName || "คำขอลาทั้งหมด";

  return (
    <>
    <AIAnalysisModal
      isOpen={analysisModalOpen}
      onClose={() => setAnalysisModalOpen(false)}
      analysis={currentAnalysis}
      isLoading={isAnalyzing}
      error={analysisError}
    />
    <Card>
      <div className="flex justify-between items-center mb-4">
          <div className="flex items-center gap-4">
              <h2 className="text-xl font-bold text-slate-800">{title}</h2>
              {!filterByEmployeeId && (
                  <div className="flex items-center space-x-2">
                      <select
                          value={selectedMonth}
                          onChange={(e) => setSelectedMonth(Number(e.target.value))}
                          className="bg-white border border-slate-300 rounded-md shadow-sm px-3 py-1.5 text-sm focus:ring-primary focus:border-primary"
                      >
                          {months.map((month, index) => (
                              <option key={index} value={index}>{month}</option>
                          ))}
                      </select>
                      <select
                          value={selectedYear}
                          onChange={(e) => setSelectedYear(Number(e.target.value))}
                          className="bg-white border border-slate-300 rounded-md shadow-sm px-3 py-1.5 text-sm focus:ring-primary focus:border-primary"
                      >
                          {availableYears.map(year => (
                              <option key={year} value={year}>{year + 543}</option>
                          ))}
                      </select>
                  </div>
              )}
          </div>
          {onClearFilter && (
            <button onClick={onClearFilter} className="bg-slate-200 text-slate-800 py-1 px-3 rounded-md hover:bg-slate-300 transition-colors text-sm">
              &larr; กลับไปภาพรวมทั้งหมด
            </button>
          )}
      </div>

      {isLoading ? <LoadingSpinner /> : (
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">พนักงาน</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ประเภท</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">วันที่ยื่นคำขอ</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ช่วงวันที่ลา</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">จำนวนวัน</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">AI Analysis</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">สถานะ</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">เอกสาร</th>
              <th className="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">จัดการ</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {filteredRequests.length > 0 ? filteredRequests.map((req) => {
                const employee = employees.find(e => e.userId === req.userId);
                const displayName = employee?.nickname || employee?.firstName || req.username;

                return (
                  <tr key={req.id} className="odd:bg-white even:bg-slate-50">
                    <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                                <img className="h-10 w-10 rounded-full object-cover" src={employee?.profileImageUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${employee?.firstName} ${employee?.lastName}`} alt={displayName} />
                            </div>
                            <div className="ml-4">
                                <div className="text-sm font-medium text-slate-900">{displayName}</div>
                                <div className="text-xs text-slate-500">{employee?.firstName} {employee?.lastName}</div>
                            </div>
                        </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-500">{leaveTypeMap[req.leaveType]}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-500">{formatDate(req.requestedAt.toDate())}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-500">{`${formatDate(new Date(req.startDate))} - ${formatDate(new Date(req.endDate))}`}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-500 text-center">{req.durationDays}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-center">
                        {req.status === 'pending' ? (
                        <button 
                            onClick={() => handleAnalyzeClick(req)}
                            disabled={isAnalyzing && analyzingRequestId === req.id}
                            className="p-1.5 rounded-full text-purple-600 bg-purple-100 hover:bg-purple-200 transition-colors disabled:opacity-50 disabled:cursor-wait"
                            title="วิเคราะห์ด้วย AI"
                        >
                            {isAnalyzing && analyzingRequestId === req.id ? (
                                <div className="w-5 h-5 border-2 border-purple-400 border-t-transparent rounded-full animate-spin"></div>
                            ) : (
                                <SparklesIcon className="w-5 h-5" />
                            )}
                        </button>
                        ) : (
                        <span className="text-slate-400">-</span>
                        )}
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-center">
                        <div className="flex flex-col items-center">
                            <span className={`px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColorMap[req.status]}`}>
                                {statusMap[req.status]}
                            </span>
                            {req.approvedAt && (
                                <span className="text-xs text-slate-400 mt-1">
                                    {formatDate(req.approvedAt.toDate())}
                                </span>
                            )}
                        </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-center">
                        <button 
                            onClick={() => handleGeneratePdf(req)} 
                            disabled={generatingPdfId === req.id}
                            className="p-1.5 rounded-full text-slate-500 hover:text-primary-700 disabled:opacity-50 disabled:cursor-wait"
                            title="ดูเอกสาร"
                        >
                            {generatingPdfId === req.id ? (
                                <div className="w-5 h-5 border-2 border-slate-400 border-t-transparent rounded-full animate-spin"></div>
                            ) : (
                                <DocumentDownloadIcon className="w-5 h-5" />
                            )}
                        </button>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-center">
                    {req.status === 'pending' ? (
                        <div className="flex justify-center items-center space-x-2">
                            <button onClick={() => handleUpdateRequest(req, LeaveStatus.APPROVED)} disabled={isProcessing === req.id} className="text-green-600 hover:text-green-900 disabled:opacity-50 disabled:cursor-wait">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                            </button>
                            <button onClick={() => handleUpdateRequest(req, LeaveStatus.REJECTED)} disabled={isProcessing === req.id} className="text-red-600 hover:text-red-900 disabled:opacity-50 disabled:cursor-wait">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.697a1 1 0 010-1.414z" clipRule="evenodd" /></svg>
                            </button>
                        </div>
                    ) : (
                        <div className="flex justify-center">
                            <button onClick={() => handleDelete(req.id)} title="ลบประวัติ" className="text-slate-400 hover:text-red-600 disabled:opacity-50">
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </div>
                    )}
                    </td>
                  </tr>
                )
            }) : (
              <tr>
                <td colSpan={9} className="px-6 py-4 text-center text-slate-500">ไม่พบคำขอลาในเดือนที่เลือก</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      )}
    </Card>
    </>
  );
};

export default AllLeaveRequests;
