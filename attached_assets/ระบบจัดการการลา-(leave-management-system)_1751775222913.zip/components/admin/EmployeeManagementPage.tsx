

import React, { useState, useEffect } from 'react';
import { collection, query, onSnapshot, orderBy, Firestore } from '../../firebase/mock';
import { EmployeeSummary, EmployeeFormData, Gender } from '../../types';
import Card from '../ui/Card';
import LoadingSpinner from '../ui/LoadingSpinner';
import EmployeeFormModal from './EmployeeFormModal';
import ResetPasswordModal from './ResetPasswordModal';
import { PencilIcon, TrashIcon, KeyIcon, MaleIcon, FemaleIcon } from '../ui/Icons';


interface EmployeeManagementPageProps {
  db: Firestore;
  appId: string;
  onSaveEmployee: (employeeData: EmployeeFormData, employeeId?: string) => Promise<void>;
  onDeleteEmployee: (employeeId: string) => Promise<void>;
  onResetPassword: (employeeId: string, newPassword: string) => Promise<void>;
  onSuccess: (message: string) => void;
  onError: (message: string) => void;
  onBack: () => void;
}

const EmployeeManagementPage: React.FC<EmployeeManagementPageProps> = (props) => {
  const { db, appId, onSaveEmployee, onDeleteEmployee, onResetPassword, onError, onBack, onSuccess } = props;
  const [employees, setEmployees] = useState<EmployeeSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<EmployeeSummary | null>(null);

  const [isResetModalOpen, setIsResetModalOpen] = useState(false);
  const [resettingEmployee, setResettingEmployee] = useState<EmployeeSummary | null>(null);

  useEffect(() => {
    const summariesCollection = collection(db, `artifacts/${appId}/public/data/employee_summaries`);
    const q = query(summariesCollection, orderBy("username"));
    
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const allEmployees: EmployeeSummary[] = [];
      querySnapshot.forEach((doc: any) => {
        if (doc.data().role !== 'admin') {
            allEmployees.push({ ...doc.data() } as EmployeeSummary);
        }
      });
      setEmployees(allEmployees);
      setIsLoading(false);
    }, (error) => {
        console.error("Error fetching employees:", error);
        onError("เกิดข้อผิดพลาดในการโหลดข้อมูลพนักงาน");
        setIsLoading(false);
    });

    return () => unsubscribe();
  }, [db, appId, onError]);
  
  const handleAddNew = () => {
    setEditingEmployee(null);
    setIsFormModalOpen(true);
  };
  
  const handleEdit = (employee: EmployeeSummary) => {
    setEditingEmployee(employee);
    setIsFormModalOpen(true);
  };
  
  const handleDelete = async (employeeId: string) => {
    try {
        await onDeleteEmployee(employeeId);
    } catch(e) {
        // error message is handled in App.tsx
    }
  };

  const handleOpenResetPassword = (employee: EmployeeSummary) => {
    setResettingEmployee(employee);
    setIsResetModalOpen(true);
  };

  const handleSavePassword = async (newPassword: string) => {
    if (!resettingEmployee) return;
    await onResetPassword(resettingEmployee.userId, newPassword);
    onSuccess(`รีเซ็ตรหัสผ่านสำหรับ ${resettingEmployee.username} สำเร็จ`);
  };

  return (
    <>
      <EmployeeFormModal 
        isOpen={isFormModalOpen}
        onClose={() => setIsFormModalOpen(false)}
        onSave={onSaveEmployee}
        onError={onError}
        initialData={editingEmployee}
      />
      {resettingEmployee && (
        <ResetPasswordModal
            isOpen={isResetModalOpen}
            onClose={() => setIsResetModalOpen(false)}
            onSave={handleSavePassword}
            employeeName={resettingEmployee.username}
        />
      )}
      <div className="p-4 md:p-8 space-y-6">
        <div className="flex justify-between items-center">
            <h1 className="text-3xl font-bold text-slate-800">จัดการพนักงาน</h1>
             <div>
                <button onClick={onBack} className="bg-slate-200 text-slate-800 py-2 px-4 rounded-md hover:bg-slate-300 transition-colors mr-3">
                    &larr; กลับไปแดชบอร์ด
                </button>
                <button onClick={handleAddNew} className="bg-primary text-white py-2 px-4 rounded-md hover:bg-primary-700 transition-colors">
                    &#43; เพิ่มพนักงานใหม่
                </button>
            </div>
        </div>

        <Card>
          <h2 className="text-xl font-bold text-slate-800 mb-4">รายชื่อพนักงานทั้งหมด</h2>
          {isLoading ? <LoadingSpinner /> : (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-slate-200">
              <thead className="bg-slate-50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ชื่อ-นามสกุล</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">ตำแหน่ง</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">EMAIL</th>
                  <th scope="col" className="px-4 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">จัดการ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {employees.length > 0 ? employees.map((employee) => {
                  const avatarBgColor = employee.gender === Gender.MALE ? '4f46e5' : '0ea5e9'; // indigo-600 : sky-500
                  const avatarUrl = employee.profileImageUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${employee.firstName} ${employee.lastName}&backgroundColor=${avatarBgColor}&textColor=ffffff&fontSize=36`;
                  
                  return (
                  <tr key={employee.userId} className="odd:bg-white even:bg-slate-50">
                    <td className="px-4 py-4 whitespace-nowrap">
                        <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                                <img className="h-10 w-10 rounded-full object-cover" src={avatarUrl} alt="" />
                            </div>
                            <div className="ml-4">
                                <div className="flex items-center">
                                    <div className="text-sm font-semibold text-slate-900 mr-2">{employee.nickname || employee.firstName}</div>
                                    {employee.gender === Gender.MALE && <MaleIcon className="w-4 h-4 text-blue-500" />}
                                    {employee.gender === Gender.FEMALE && <FemaleIcon className="w-4 h-4 text-pink-500" />}
                                </div>
                                <div className="text-xs text-slate-500">{employee.firstName} {employee.lastName}</div>
                                <div className="text-xs text-slate-400">@{employee.username}</div>
                            </div>
                        </div>
                    </td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-500">{employee.position || '-'}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-slate-500">{employee.email || '-'}</td>
                    <td className="px-4 py-4 whitespace-nowrap text-sm text-center font-medium">
                        <div className="flex items-center justify-center space-x-4">
                            <button onClick={() => handleOpenResetPassword(employee)} title="รีเซ็ตรหัสผ่าน" className="text-slate-500 hover:text-primary-700">
                                <KeyIcon className="w-5 h-5" />
                            </button>
                            <button onClick={() => handleEdit(employee)} title="แก้ไขข้อมูล" className="text-primary-600 hover:text-primary-900">
                               <PencilIcon className="w-5 h-5" />
                            </button>
                            <button onClick={() => handleDelete(employee.userId)} title="ลบ" className="text-red-600 hover:text-red-900">
                                <TrashIcon className="w-5 h-5" />
                            </button>
                        </div>
                    </td>
                  </tr>
                  )
                }) : (
                  <tr>
                    <td colSpan={4} className="px-6 py-4 text-center text-slate-500">ไม่พบข้อมูลพนักงาน</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          )}
        </Card>
      </div>
    </>
  );
};

export default EmployeeManagementPage;
