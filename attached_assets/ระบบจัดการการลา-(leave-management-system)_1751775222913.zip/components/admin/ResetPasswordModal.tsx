import React, { useState } from 'react';
import Card from '../ui/Card';

interface ResetPasswordModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (newPassword: string) => Promise<void>;
    employeeName: string;
}

const ResetPasswordModal: React.FC<ResetPasswordModalProps> = ({ isOpen, onClose, onSave, employeeName }) => {
    const [password, setPassword] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState('');

    if (!isOpen) return null;

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (password.length < 6) {
            setError('รหัสผ่านต้องมีความยาวอย่างน้อย 6 ตัวอักษร');
            return;
        }
        setError('');
        setIsSubmitting(true);
        try {
            await onSave(password);
            onClose();
        } catch (err) {
            setError('เกิดข้อผิดพลาดในการรีเซ็ตรหัสผ่าน');
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex justify-center items-center p-4" onClick={onClose}>
            <div className="relative w-full max-w-md" onClick={e => e.stopPropagation()}>
                <Card>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-xl font-bold text-slate-800">รีเซ็ตรหัสผ่าน</h2>
                        <button onClick={onClose} className="p-1 rounded-full text-slate-500 hover:bg-slate-200">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </button>
                    </div>
                    <p className="text-slate-600 mb-4">
                        คุณกำลังจะรีเซ็ตรหัสผ่านสำหรับ <strong className="text-slate-800">{employeeName}</strong>
                    </p>
                    <form onSubmit={handleSubmit} className="space-y-4">
                        <div>
                            <label htmlFor="newPassword"className="block text-sm font-medium text-slate-700">
                                รหัสผ่านใหม่
                            </label>
                            <input
                                id="newPassword"
                                name="newPassword"
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                className="mt-1 block w-full border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm"
                            />
                        </div>
                        {error && <p className="text-sm text-red-500">{error}</p>}
                        <div className="flex justify-end space-x-3 pt-4">
                            <button type="button" onClick={onClose} className="bg-slate-200 text-slate-800 py-2 px-4 rounded-md hover:bg-slate-300 transition-colors">
                                ยกเลิก
                            </button>
                            <button type="submit" disabled={isSubmitting} className="bg-primary text-white py-2 px-4 rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors disabled:bg-slate-400">
                                {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกรหัสผ่านใหม่'}
                            </button>
                        </div>
                    </form>
                </Card>
            </div>
        </div>
    );
};

export default ResetPasswordModal;
