
import React from 'react';
import { AIDailyBriefing } from '../../types';
import Card from '../ui/Card';
import { InformationCircleIcon, ArrowPathIcon } from '../ui/Icons';
import LoadingSpinner from '../ui/LoadingSpinner';

interface AIDailyBriefingCardProps {
    briefing: AIDailyBriefing | null;
    isLoading: boolean;
    error: string | null;
    onRefresh: () => void;
}

const AIDailyBriefingCard: React.FC<AIDailyBriefingCardProps> = ({ briefing, isLoading, error, onRefresh }) => {
    return (
        <Card className="bg-gradient-to-br from-primary-50 to-sky-100 border-primary-200">
            <div className="flex justify-between items-start mb-4">
                <div className="flex items-center">
                    <div className="bg-primary/20 text-primary-700 p-2 rounded-lg mr-4">
                        <InformationCircleIcon className="w-6 h-6" />
                    </div>
                    <div>
                        <h2 className="text-xl font-bold text-slate-800">AI Daily Briefing</h2>
                        <p className="text-sm text-slate-500">สรุปภาพรวมและข้อมูลสำคัญประจำวัน</p>
                    </div>
                </div>
                <button 
                    onClick={onRefresh} 
                    disabled={isLoading}
                    className="p-1.5 rounded-full text-slate-500 hover:bg-slate-200 transition-colors disabled:cursor-wait"
                    title="รีเฟรชข้อมูล"
                >
                    <ArrowPathIcon className={`w-5 h-5 ${isLoading ? 'animate-spin' : ''}`} />
                </button>
            </div>

            <div className="min-h-[150px] flex items-center justify-center">
                 {isLoading && <LoadingSpinner />}
                 
                 {error && !isLoading && (
                    <div className="text-center p-4 bg-red-50 text-red-700 rounded-lg w-full">
                        <h3 className="font-bold">เกิดข้อผิดพลาด</h3>
                        <p className="text-sm">{error}</p>
                    </div>
                 )}

                 {briefing && !isLoading && (
                    <div className="w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
                        <BriefingSection title="คำขอที่ต้องจัดการ">
                            <p className="text-4xl font-bold text-primary">{briefing.pendingRequestsCount}</p>
                            <p className="text-slate-600">รายการ</p>
                        </BriefingSection>
                        <BriefingSection title="รายการเร่งด่วน">
                             {briefing.urgentItems.length > 0 ? (
                                <ul className="list-disc list-inside space-y-1 text-slate-700">
                                    {briefing.urgentItems.map((item, index) => <li key={index}>{item}</li>)}
                                </ul>
                             ) : <p className="text-slate-500 italic">ไม่มีรายการเร่งด่วน</p>}
                        </BriefingSection>
                         <BriefingSection title="ข้อสังเกตจาก AI">
                             {briefing.observations.length > 0 ? (
                                <ul className="list-disc list-inside space-y-1 text-slate-700">
                                    {briefing.observations.map((item, index) => <li key={index}>{item}</li>)}
                                </ul>
                             ) : <p className="text-slate-500 italic">ไม่มีข้อสังเกตพิเศษ</p>}
                        </BriefingSection>
                        <div className="md:col-span-2 lg:col-span-3">
                            <BriefingSection title="คำแนะนำจาก AI">
                                <p className="text-slate-700">{briefing.proactiveSuggestion}</p>
                            </BriefingSection>
                        </div>
                    </div>
                 )}
            </div>
        </Card>
    );
};

const BriefingSection: React.FC<{title: string; children: React.ReactNode}> = ({ title, children }) => (
    <div className="bg-white/50 p-4 rounded-lg h-full">
        <h3 className="font-semibold text-slate-800 mb-2">{title}</h3>
        {children}
    </div>
);

export default AIDailyBriefingCard;
