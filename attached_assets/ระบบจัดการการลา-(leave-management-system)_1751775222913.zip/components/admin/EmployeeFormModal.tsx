
import React, { useState, useEffect } from 'react';
import Card from '../ui/Card';
import { EmployeeSummary, EmployeeFormData, LeaveBalances, Gender, Title } from '../../types';
import { defaultLeaveBalances, leaveTypeMap, leaveBalanceKeyToLeaveTypeMap, titleMap } from '../../constants';
import { PencilIcon } from '../ui/Icons';

interface EmployeeFormModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (employeeData: EmployeeFormData, employeeId?: string) => Promise<void>;
    onError: (message: string) => void;
    initialData: EmployeeSummary | null;
}

const EmployeeFormModal: React.FC<EmployeeFormModalProps> = ({ isOpen, onClose, onSave, onError, initialData }) => {
    const getInitialFormState = (): EmployeeFormData => ({
        username: initialData?.username || '',
        password: '',
        firstName: initialData?.firstName || '',
        lastName: initialData?.lastName || '',
        nickname: initialData?.nickname || '',
        title: initialData?.title || Title.NANGSAO,
        gender: initialData?.gender || Gender.FEMALE,
        email: initialData?.email || '',
        mobilePhone: initialData?.mobilePhone || '',
        profileImageUrl: initialData?.profileImageUrl || '',
        lineUserId: initialData?.lineUserId || '',
        position: initialData?.position || '',
        facebook: initialData?.facebook || '',
        instagram: initialData?.instagram || '',
        address: initialData?.address || '',
        leaveBalances: initialData?.leaveBalances || defaultLeaveBalances,
    });

    const [formData, setFormData] = useState<EmployeeFormData>(getInitialFormState());
    const [isSubmitting, setIsSubmitting] = useState(false);

    useEffect(() => {
        setFormData(getInitialFormState());
    }, [initialData, isOpen]);

    if (!isOpen) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleTitleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newTitle = e.target.value as Title;
        const newGender = (newTitle === Title.NAI) ? Gender.MALE : Gender.FEMALE;
        setFormData(prev => ({ 
            ...prev, 
            title: newTitle,
            gender: newGender,
        }));
    };

    const handleBalanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        const balanceKey = name as keyof LeaveBalances;
        const numericValue = parseInt(value, 10);

        // This handles empty string (by setting to 0) and valid numbers,
        // while ignoring invalid characters like 'e' or '-' that parseInt would fail on.
        if (value === '' || (!isNaN(numericValue) && numericValue >= 0)) {
            setFormData(prev => ({
                ...prev,
                leaveBalances: {
                    ...prev.leaveBalances,
                    [balanceKey]: value === '' ? 0 : numericValue,
                },
            }));
        }
    };
    
    const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        // Optional: Add file size validation
        if (file.size > 2 * 1024 * 1024) { // 2MB limit
            onError("ขนาดไฟล์รูปภาพต้องไม่เกิน 2MB");
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            setFormData(prev => ({
                ...prev,
                profileImageUrl: reader.result as string,
            }));
        };
        reader.readAsDataURL(file);
    };


    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!formData.username || !formData.firstName || !formData.lastName || !formData.email || !formData.title) {
            onError("กรุณากรอกข้อมูลที่จำเป็นให้ครบถ้วน: คำนำหน้าชื่อ, ชื่อ, นามสกุล, ชื่อผู้ใช้, และอีเมล");
            return;
        }
        if (!initialData && !formData.password) {
            onError("ต้องกำหนดรหัสผ่านสำหรับพนักงานใหม่");
            return;
        }
        setIsSubmitting(true);
        try {
            const dataToSave = {...formData};
            if(initialData && !dataToSave.password) {
                delete dataToSave.password;
            }
            await onSave(dataToSave, initialData?.userId);
            onClose(); // Close modal on success
        } catch (error) {
            console.error(error);
        } finally {
            setIsSubmitting(false);
        }
    };
    
    const title = initialData ? 'แก้ไขข้อมูลพนักงาน' : 'เพิ่มพนักงานใหม่';

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 flex justify-center items-start p-4" onClick={onClose}>
            <div className="relative w-full max-w-3xl max-h-[95vh] overflow-y-auto mt-8" onClick={e => e.stopPropagation()}>
                <Card className="p-0">
                    <div className="sticky top-0 bg-white p-6 border-b border-slate-200 z-10">
                        <div className="flex justify-between items-center">
                            <h2 className="text-2xl font-bold text-slate-800">{title}</h2>
                            <button onClick={onClose} className="p-1 rounded-full text-slate-500 hover:bg-slate-200 transition-colors">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                            </button>
                        </div>
                    </div>
                    
                    <form onSubmit={handleSubmit}>
                      <div className="p-6 space-y-6">
                        <Section title="ข้อมูลส่วนตัว">
                            <div className="flex justify-center mb-6">
                                <div className="relative">
                                    <label htmlFor="photoUpload" className="cursor-pointer group">
                                        <img
                                            src={formData.profileImageUrl || `https://api.dicebear.com/8.x/initials/svg?seed=${formData.firstName} ${formData.lastName}&backgroundColor=0284c7&textColor=ffffff&fontSize=40`}
                                            alt="Profile"
                                            className="w-28 h-28 rounded-full object-cover border-4 border-white shadow-lg"
                                        />
                                        <div className="absolute inset-0 rounded-full bg-black bg-opacity-0 group-hover:bg-opacity-40 flex items-center justify-center transition-opacity duration-300">
                                            <PencilIcon className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                                        </div>
                                    </label>
                                    <input
                                        id="photoUpload"
                                        type="file"
                                        accept="image/png, image/jpeg, image/webp"
                                        className="hidden"
                                        onChange={handlePhotoChange}
                                    />
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-6 gap-y-4">
                                <div>
                                    <label htmlFor="title" className="block text-sm font-medium text-slate-700">
                                        คำนำหน้าชื่อ <span className="text-red-500">*</span>
                                    </label>
                                    <select
                                        id="title"
                                        name="title"
                                        value={formData.title}
                                        onChange={handleTitleChange}
                                        required
                                        className="mt-1 block w-full border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm transition-shadow"
                                    >
                                        {Object.entries(titleMap).map(([key, value]) => (
                                            <option key={key} value={key}>{value}</option>
                                        ))}
                                    </select>
                                </div>
                                <InputField label="ชื่อ" name="firstName" value={formData.firstName} onChange={handleChange} required />
                                <InputField label="นามสกุล" name="lastName" value={formData.lastName} onChange={handleChange} required />
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                                <InputField label="ชื่อเล่น" name="nickname" value={formData.nickname} onChange={handleChange} />
                                <InputField label="ตำแหน่ง" name="position" value={formData.position} onChange={handleChange} />
                            </div>
                            <InputField label="เบอร์โทรศัพท์" name="mobilePhone" value={formData.mobilePhone} onChange={handleChange} />
                            <InputField label="ที่อยู่" name="address" value={formData.address} onChange={handleChange} isTextArea />
                        </Section>

                        <Section title="ข้อมูลสำหรับเข้าระบบ">
                             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-4">
                                <InputField label="ชื่อผู้ใช้" name="username" value={formData.username} onChange={handleChange} required />
                                <InputField 
                                    label="รหัสผ่าน" 
                                    name="password" 
                                    type="password"
                                    value={formData.password}
                                    onChange={handleChange} 
                                    required={!initialData} 
                                    placeholder={initialData ? "เว้นว่างไว้เพื่อคงรหัสผ่านเดิม" : "ตั้งรหัสผ่าน"}
                                />
                            </div>
                        </Section>

                        <Section title="จัดการวันลาคงเหลือ">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-x-6 gap-y-4">
                                {(Object.keys(formData.leaveBalances) as Array<keyof LeaveBalances>).map((key) => (
                                    <div key={key}>
                                        <label htmlFor={key} className="block text-sm font-medium text-slate-700">
                                            {leaveTypeMap[leaveBalanceKeyToLeaveTypeMap[key]]}
                                        </label>
                                        <input
                                            type="number"
                                            id={key}
                                            name={key}
                                            value={formData.leaveBalances[key]}
                                            onChange={handleBalanceChange}
                                            min="0"
                                            className="mt-1 block w-full border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm transition-shadow"
                                        />
                                    </div>
                                ))}
                            </div>
                        </Section>

                        <Section title="ข้อมูลการติดต่อและอื่นๆ">
                            <InputField label="Email" name="email" type="email" value={formData.email} onChange={handleChange} required />
                            <InputField label="Line User ID" name="lineUserId" value={formData.lineUserId} onChange={handleChange} />
                            <InputField label="Facebook Profile URL" name="facebook" value={formData.facebook} onChange={handleChange} placeholder="https://..." />
                            <InputField label="Instagram Profile URL" name="instagram" value={formData.instagram} onChange={handleChange} placeholder="https://..." />
                        </Section>
                      </div>

                      <div className="sticky bottom-0 flex justify-end space-x-3 p-6 bg-slate-50 border-t border-slate-200">
                          <button type="button" onClick={onClose} className="bg-slate-200 text-slate-800 py-2 px-4 rounded-md hover:bg-slate-300 transition-colors">
                              ยกเลิก
                          </button>
                           <button type="submit" disabled={isSubmitting} className="bg-primary text-white py-2 px-4 rounded-md hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-colors disabled:bg-slate-400">
                              {isSubmitting ? 'กำลังบันทึก...' : 'บันทึกข้อมูล'}
                          </button>
                      </div>
                    </form>
                </Card>
            </div>
        </div>
    );
};

const Section: React.FC<{title: string, children: React.ReactNode}> = ({ title, children }) => (
    <div className="space-y-4">
        <h3 className="text-lg font-semibold text-slate-700 border-b border-slate-200 pb-2">{title}</h3>
        <div className="space-y-4 pt-2">
            {children}
        </div>
    </div>
);

interface InputFieldProps {
    label: string;
    name: keyof Omit<EmployeeFormData, 'leaveBalances' | 'profileImageUrl' | 'gender' | 'title'>;
    value?: string;
    onChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
    type?: string;
    required?: boolean;
    placeholder?: string;
    isTextArea?: boolean;
}

const InputField: React.FC<InputFieldProps> = ({ label, name, value, onChange, type = 'text', required = false, placeholder, isTextArea = false }) => {
    const commonProps = {
        id: name,
        name: name,
        value: value,
        onChange: onChange,
        required: required,
        placeholder: placeholder || label,
        className: "mt-1 block w-full border-slate-300 rounded-md shadow-sm focus:ring-primary focus:border-primary sm:text-sm transition-shadow"
    };

    return (
        <div>
            <label htmlFor={name} className="block text-sm font-medium text-slate-700">
                {label} {required && <span className="text-red-500">*</span>}
            </label>
            {isTextArea ? (
                <textarea {...commonProps} rows={3}></textarea>
            ) : (
                <input type={type} {...commonProps} />
            )}
        </div>
    );
};

export default EmployeeFormModal;