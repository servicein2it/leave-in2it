

import { UserData, Role, LeaveRequest, LeaveStatus, EmployeeSummary, LeaveType, LeaveBalances, Notification, Gender, Title } from '../types';
import { defaultLeaveBalances } from '../constants';

export class Timestamp {
    constructor(public seconds: number, public nanoseconds: number) {}
    static now = () => { const now = Date.now(); return new Timestamp(Math.floor(now / 1000), (now % 1000) * 1e6); }
    toDate = () => new Date(this.seconds * 1000 + this.nanoseconds / 1e6);
    toMillis = () => this.seconds * 1000 + this.nanoseconds / 1e6;
}

const ADMIN_ID = 'admin_user_001';
const ADMIN_USERNAME = 'admin';

// --- MOCK DATA STORE ---
interface DbStore {
    users: Record<string, { user_data: Record<string, UserData> }>;
    public: {
        data: {
            employee_summaries: Record<string, EmployeeSummary>;
            leave_requests: Record<string, Omit<LeaveRequest, 'id'>>;
            notifications: Record<string, Omit<Notification, 'id'>>;
        };
    };
}
let MOCK_DB: DbStore = {
    users: {
        [ADMIN_ID]: {
            user_data: {
                [ADMIN_ID]: {
                    userId: ADMIN_ID,
                    username: ADMIN_USERNAME,
                    password: 'admin', // Default admin password
                    firstName: 'ผู้ดูแลระบบ',
                    lastName: '',
                    nickname: 'แอดมิน',
                    title: Title.NAI,
                    gender: Gender.MALE,
                    position: 'Administrator',
                    role: Role.ADMIN,
                    leaveBalances: { sickLeave: 99, maternityLeave: 99, sterilizationLeave: 99, personalBusinessLeave: 99, annualLeave: 99, militaryLeave: 99, accumulatedLeave: 99 },
                    createdAt: new Timestamp(Date.now() / 1000 - 1000, 0),
                    updatedAt: new Timestamp(Date.now() / 1000 - 1000, 0),
                }
            }
        },
    },
    public: { 
        data: { 
            employee_summaries: {
                [ADMIN_ID]: {
                    userId: ADMIN_ID,
                    username: ADMIN_USERNAME,
                    firstName: 'ผู้ดูแลระบบ',
                    lastName: '',
                    nickname: 'แอดมิน',
                    title: Title.NAI,
                    gender: Gender.MALE,
                    position: 'Administrator',
                    role: Role.ADMIN,
                    leaveBalances: { sickLeave: 99, maternityLeave: 99, sterilizationLeave: 99, personalBusinessLeave: 99, annualLeave: 99, militaryLeave: 99, accumulatedLeave: 99 },
                    updatedAt: new Timestamp(Date.now() / 1000 - 1000, 0),
                },
            }, 
            leave_requests: {},
            notifications: {},
        } 
    },
};

let MOCK_CURRENT_USER: UserData | null = null;
let authStateListener: ((user: UserData | null) => void) | null = null;

const listeners = new Map<any, Function[]>();

// --- UTILS ---
const deepClone = <T>(obj: T): T => JSON.parse(JSON.stringify(obj, (key, value) => {
    if (value && value.seconds !== undefined && value.nanoseconds !== undefined) {
        return { _isTimestamp: true, seconds: value.seconds, nanoseconds: value.nanoseconds };
    }
    return value;
}), (key, value) => {
    if (value && value._isTimestamp) {
        return new Timestamp(value.seconds, value.nanoseconds);
    }
    return value;
});

const getRefKey = (ref: any): string => {
    return JSON.stringify(ref, (key, value) => {
        if (value instanceof Timestamp) return value.toMillis();
        return value;
    });
};

const generateSnapshotForRef = (refKey: string) => {
    const ref = JSON.parse(refKey);

    if (typeof ref === 'object' && ref.collection) { // Query snapshot
        let items: any[] = [];
        if (ref.collection.includes('leave_requests')) {
            items = Object.entries(MOCK_DB.public.data.leave_requests).map(([id, data]) => ({ id, ...data }));
        } else if (ref.collection.includes('employee_summaries')) {
            items = Object.values(MOCK_DB.public.data.employee_summaries);
        } else if (ref.collection.includes('notifications')) {
            items = Object.entries(MOCK_DB.public.data.notifications).map(([id, data]) => ({ id, ...data }));
        }

        (ref.constraints || []).forEach((c:any) => {
            if (c.type === 'where') items = items.filter(item => item[c.field] === c.value);
            if (c.type === 'orderBy') {
                items.sort((a, b) => {
                    const valA = a[c.field] instanceof Timestamp ? a[c.field].toMillis() : a[c.field];
                    const valB = b[c.field] instanceof Timestamp ? b[c.field].toMillis() : b[c.field];
                    let comparison = valA > valB ? 1 : (valA < valB ? -1 : 0);
                    return c.dir === 'desc' ? -comparison : comparison;
                });
            }
        });
        
        return {
            docs: items.map(item => ({ id: item.id || item.userId, data: () => deepClone(item) })),
            forEach: function(cb: any) { this.docs.forEach(cb) }
        };

    } else { // Document snapshot
        const path = String(ref);
        const pathParts = path.split('/');
        let data;
        if(path.includes('user_data')){
             const uid = pathParts[3];
             data = MOCK_DB.users[uid]?.user_data?.[uid];
        }
        return {
            exists: () => !!data,
            data: () => data ? deepClone(data) : undefined,
        };
    }
};

const triggerListenersForRef = (refKey: string) => {
    const callbacks = listeners.get(refKey);
    if (callbacks) {
        const snapshot = generateSnapshotForRef(refKey);
        callbacks.forEach(cb => cb(snapshot));
    }
};

const triggerAllListeners = () => {
    for (const key of listeners.keys()) {
        triggerListenersForRef(key);
    }
};


// --- MOCK FIREBASE PUBLIC API ---

export type Unsubscribe = () => void;
export type User = UserData; // The user object is now the full UserData
export type FirebaseApp = { name: string };
export type Auth = { name: string };
export type Firestore = { name: string };

export const initializeApp = (config: any): FirebaseApp => ({ name: 'mockApp' });
export const getAuth = (app?: any): Auth => ({ name: 'mockAuth' });
export const getFirestore = (app?: any): Firestore => ({ name: 'mockDb' });

export const onAuthStateChanged = (auth: any, callback: (user: User | null) => void): Unsubscribe => {
    authStateListener = callback;
    // This is now primarily for session persistence simulation, not initial login
    setTimeout(() => authStateListener && authStateListener(MOCK_CURRENT_USER), 50);
    return () => { authStateListener = null; };
};

export const signInWithUsernameAndPassword = async (auth: any, username: string, password?: string): Promise<{user: UserData}> => {
    if (!password) {
        throw new Error("Password is required.");
    }

    const allUsers = Object.values(MOCK_DB.users).map(u => u.user_data[Object.keys(u.user_data)[0]]);
    const foundUser = allUsers.find(u => u.username.toLowerCase() === username.toLowerCase());
    
    if (foundUser && foundUser.password === password) {
        MOCK_CURRENT_USER = deepClone(foundUser);
        if (authStateListener) authStateListener(MOCK_CURRENT_USER);
        return { user: MOCK_CURRENT_USER };
    } else {
        throw new Error("Authentication failed. Invalid username or password.");
    }
};

// Deprecated in this flow but keep for compatibility if needed elsewhere.
export const signInAnonymously = async (auth: any) => ({ user: { uid: 'anonymous' } });
export const signInWithCustomToken = async (auth: any, token: string) => ({ user: { uid: 'custom' } });

export const signOut = async (auth: any) => { 
    MOCK_CURRENT_USER = null; 
    if (authStateListener) authStateListener(null); 
};


export const serverTimestamp = () => Timestamp.now();

export const doc = (db: any, path: string, ...segments: string[]) => [path, ...segments].join('/');
export const collection = (db: any, path: string) => path;
export const query = (ref: string, ...constraints: any[]) => ({ collection: ref, constraints });
export const where = (field: string, op: string, value: any) => ({ type: 'where', field, op, value });
export const orderBy = (field: string, dir: 'asc' | 'desc' = 'asc') => ({ type: 'orderBy', field, dir });

export const onSnapshot = (ref: any, callback: (snapshot: any) => void, onError?: (error: Error) => void): Unsubscribe => {
    const key = getRefKey(ref);
    if (!listeners.has(key)) listeners.set(key, []);
    listeners.get(key)!.push(callback);
    
    setTimeout(() => triggerListenersForRef(key), 50);

    return () => {
        const cbs = listeners.get(key);
        if (cbs) listeners.set(key, cbs.filter(cb => cb !== callback));
    };
};

export const getDoc = async (docRef: string) => {
    const refKey = getRefKey(docRef);
    return generateSnapshotForRef(refKey);
};

export const getDocs = async (queryRef: any) => {
    const refKey = getRefKey(queryRef);
    return generateSnapshotForRef(refKey);
};


export const addDoc = async (collectionRef: string, data: any) => {
    const id = `mock_${Date.now()}`;
    if (collectionRef.includes('leave_requests')) {
        MOCK_DB.public.data.leave_requests[id] = { ...data, id, status: 'pending' };
    }
    triggerAllListeners();
    return { id };
};

export const writeBatch = (db: any) => {
    const operations: { ref: string; data?: any; type: 'set' | 'update' | 'delete' }[] = [];
    const batch = {
        set: (docRef: string, data: any) => {
            operations.push({ ref: docRef, data: deepClone(data), type: 'set' });
            return batch;
        },
        update: (docRef: string, data: any) => {
            operations.push({ ref: docRef, data: deepClone(data), type: 'update' });
            return batch;
        },
        delete: (docRef: string) => {
            operations.push({ ref: docRef, type: 'delete' });
            return batch;
        },
        commit: async () => {
            operations.forEach(({ ref, data, type }) => {
                const parts = ref.split('/');
                const uid = ref.includes('user_data') ? parts[3] : (ref.includes('employee_summaries') ? parts[5] : '');


                const updateUser = (target:any) => {
                    const clonedData = { ...data };
                    // Don't overwrite password if it's not explicitly provided in the update
                    if (type === 'update' && !clonedData.hasOwnProperty('password')) {
                         clonedData.password = target.password;
                    }
                    return { ...target, ...clonedData };
                };
                
                if (ref.includes('user_data')) {
                     if (type === 'delete') {
                        delete MOCK_DB.users[uid];
                    } else {
                        if (!MOCK_DB.users[uid]) MOCK_DB.users[uid] = { user_data: {} };
                        const existing = MOCK_DB.users[uid].user_data[uid] || {};
                        MOCK_DB.users[uid].user_data[uid] = updateUser(existing);
                    }
                } else if (ref.includes('employee_summaries')) {
                     if (type === 'delete') {
                        delete MOCK_DB.public.data.employee_summaries[uid];
                    } else {
                        const existing = MOCK_DB.public.data.employee_summaries[uid] || {};
                        // Passwords should not be in summaries.
                        const { password, ...summaryData } = data;
                        MOCK_DB.public.data.employee_summaries[uid] = { ...existing, ...summaryData };
                    }
                } else if (ref.includes('notifications')) {
                    const notifId = parts[5];
                    if (type === 'update') {
                        const existing = MOCK_DB.public.data.notifications[notifId] || {};
                        MOCK_DB.public.data.notifications[notifId] = {...existing, ...data};
                    }
                }
            });
            triggerAllListeners();
        },
    };
    return batch;
};

export const runTransaction = async (db: any, updateFunction: (tx: any) => Promise<any>) => {
    const tempDb = deepClone(MOCK_DB);
    let error: Error | null = null;

    const transaction = {
        get: async (docRef: string) => {
             const parts = docRef.split('/');
             if(docRef.includes('user_data')) {
                 const uid = parts[3];
                 const data = tempDb.users[uid]?.user_data?.[uid];
                 return { exists: () => !!data, data: () => data };
             }
             return { exists: () => false, data: () => undefined };
        },
        set: (docRef: string, setData: any) => {
            const parts = docRef.split('/');
            if(docRef.includes('notifications')){
                const id = parts[5];
                tempDb.public.data.notifications[id] = setData;
            }
        },
        update: (docRef: string, updateData: any) => {
            const parts = docRef.split('/');
            if(docRef.includes('leave_requests')){
                const id = parts[5];
                const req = tempDb.public.data.leave_requests[id];
                if(req) tempDb.public.data.leave_requests[id] = {...req, ...updateData};
            } else if(docRef.includes('user_data')) {
                const uid = parts[3];
                const user = tempDb.users[uid]?.user_data?.[uid];
                if(user) tempDb.users[uid].user_data[uid] = {...user, ...updateData};
            } else if(docRef.includes('employee_summaries')) {
                const uid = parts[5];
                const summary = tempDb.public.data.employee_summaries[uid];
                if(summary) tempDb.public.data.employee_summaries[uid] = {...summary, ...updateData};
            }
        }
    };

    try {
        await updateFunction(transaction);
        MOCK_DB = tempDb;
    } catch(e) {
        error = e as Error;
        console.error("Mock transaction failed:", e);
    }
    
    triggerAllListeners();
    if(error) throw error;
};
