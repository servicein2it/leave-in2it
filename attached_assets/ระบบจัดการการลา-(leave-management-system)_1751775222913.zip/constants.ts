
import { LeaveType, LeaveStatus, LeaveBalances, Title } from './types';

export const titleMap: Record<Title, string> = {
  [Title.NAI]: 'นาย',
  [Title.NANG]: 'นาง',
  [Title.NANGSAO]: 'นางสาว',
};

export const leaveTypeMap: Record<LeaveType, string> = {
  [LeaveType.SICK]: 'ลาป่วย',
  [LeaveType.MATERNITY]: 'ลาคลอด',
  [LeaveType.STERILIZATION]: 'ลาทำหมัน',
  [LeaveType.PERSONAL_BUSINESS]: 'ลากิจส่วนตัว',
  [LeaveType.ANNUAL]: 'ลาพักร้อน',
  [LeaveType.MILITARY]: 'ลารับราชการทหาร',
  [LeaveType.ACCUMULATED]: 'วันลาสะสม',
};

export const leaveTypeToBalanceKey: Record<LeaveType, keyof LeaveBalances> = {
  [LeaveType.SICK]: 'sickLeave',
  [LeaveType.MATERNITY]: 'maternityLeave',
  [LeaveType.STERILIZATION]: 'sterilizationLeave',
  [LeaveType.PERSONAL_BUSINESS]: 'personalBusinessLeave',
  [LeaveType.ANNUAL]: 'annualLeave',
  [LeaveType.MILITARY]: 'militaryLeave',
  [LeaveType.ACCUMULATED]: 'accumulatedLeave',
};


export const leaveBalanceKeyToLeaveTypeMap: Record<keyof LeaveBalances, LeaveType> = {
  sickLeave: LeaveType.SICK,
  maternityLeave: LeaveType.MATERNITY,
  sterilizationLeave: LeaveType.STERILIZATION,
  personalBusinessLeave: LeaveType.PERSONAL_BUSINESS,
  annualLeave: LeaveType.ANNUAL,
  militaryLeave: LeaveType.MILITARY,
  accumulatedLeave: LeaveType.ACCUMULATED,
};

export const statusMap: Record<LeaveStatus, string> = {
  [LeaveStatus.PENDING]: 'รอดำเนินการ',
  [LeaveStatus.APPROVED]: 'อนุมัติแล้ว',
  [LeaveStatus.REJECTED]: 'ปฏิเสธแล้ว',
};

export const statusColorMap: Record<LeaveStatus, string> = {
  [LeaveStatus.PENDING]: 'bg-yellow-100 text-yellow-800 border-yellow-300',
  [LeaveStatus.APPROVED]: 'bg-green-100 text-green-800 border-green-300',
  [LeaveStatus.REJECTED]: 'bg-red-100 text-red-800 border-red-300',
};

export const defaultLeaveBalances: LeaveBalances = {
    sickLeave: 0,
    maternityLeave: 0,
    sterilizationLeave: 0,
    personalBusinessLeave: 0,
    annualLeave: 0,
    militaryLeave: 0,
    accumulatedLeave: 0,
};