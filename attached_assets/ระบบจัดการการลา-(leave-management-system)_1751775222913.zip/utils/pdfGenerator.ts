
import { LeaveRequest, UserData, EmployeeSummary, Gender, LeaveType } from '../types';
import { formatThaiDateParts } from './dateHelpers';
import { leaveTypeMap, titleMap } from '../constants';

export const generatePdfForRequest = async (request: LeaveRequest, employee: UserData | EmployeeSummary): Promise<void> => {
    
    if (!employee) {
        throw new Error('Employee data not found for PDF generation.');
    }

    const requestDate = formatThaiDateParts(request.requestedAt.toDate());
    const startDate = formatThaiDateParts(new Date(request.startDate));
    const endDate = formatThaiDateParts(new Date(request.endDate));
    const employeeTitle = employee.title ? titleMap[employee.title] : (employee.gender === Gender.MALE ? 'นาย' : 'นาง/นางสาว');
    
    const isSick = request.leaveType === LeaveType.SICK;
    const isPersonal = request.leaveType === LeaveType.PERSONAL_BUSINESS;
    
    const otherLeaveDetails = !isSick && !isPersonal 
        ? `${leaveTypeMap[request.leaveType] || 'ลาประเภทอื่น'}${request.notes ? `: ${request.notes}` : ''}`
        : 'ตามที่ได้รับอนุมัติ';

    const printHtml = `
    <!DOCTYPE html>
    <html lang="th">
    <head>
        <meta charset="UTF-8">
        <title>ใบลา - ${employee.firstName} ${employee.lastName}</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap" rel="stylesheet">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@300;400;500;600;700&display=swap');
            
            body { 
                font-family: 'Kanit', sans-serif; 
                background: #e2e8f0; 
                margin: 0; 
                padding: 2rem;
                display: flex;
                justify-content: center;
                align-items: flex-start;
                -webkit-print-color-adjust: exact;
                color-adjust: exact;
            }
            .page-container {
                background: white;
                width: 210mm;
                min-height: 297mm;
                padding: 15mm;
                box-sizing: border-box;
                box-shadow: 0 0 15px rgba(0,0,0,0.15);
                margin: auto;
            }
            .content-wrapper {
                color: #333; 
                line-height: 1.6;
                font-size: 14px;
            }
            .dotted { 
                border-bottom: 1px dotted #000; 
                display: inline-block; 
                min-width: 80px; 
                padding: 0 5px; 
                text-align: center; 
                line-height: 1.2;
                vertical-align: bottom;
                font-weight: 500;
            }
            .checkbox { 
                width: 16px; 
                height: 16px; 
                border: 1.5px solid #000; 
                display: inline-block; 
                vertical-align: middle; 
                margin-right: 8px; 
                position: relative;
                top: -1px;
            }
            .checkbox.checked::after { 
                content: '✔'; 
                font-size: 14px; 
                line-height: 16px; 
                text-align: center; 
                display: block;
                position: absolute;
                top: 0px;
                left: 1px;
            }
            header, main, footer {
                width: 100%;
            }
            p { margin: 0; }
            main p {
                line-height: 2.8;
            }

            @media print {
                body {
                    background: none;
                    padding: 0;
                    margin: 0;
                }
                .page-container {
                    width: 100%;
                    min-height: auto;
                    box-shadow: none;
                    margin: 0;
                    padding: 0;
                }
                @page {
                    size: A4;
                    margin: 15mm;
                }
            }
        </style>
    </head>
    <body>
        <div class="page-container">
            <div class="content-wrapper">
            
            <header style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px;">
                <div style="flex: 1;">
                    <img src="https://in2it-service.com/IN2IT/logo/in2it-logo.png" style="width: 120px;" alt="IN2IT Logo"/>
                    <p style="font-size: 12px; margin-top: 5px; color: #555;">IN2IT COMPANY</p>
                </div>
                <div style="flex: 2; text-align: center;">
                    <h1 style="font-size: 24px; font-weight: bold; margin: 0;">ใบลา</h1>
                </div>
                <div style="flex: 1.5; text-align: right; white-space: nowrap;">
                    วันที่ <span class="dotted" style="min-width: 40px;">${requestDate.day}</span>
                    เดือน <span class="dotted">${requestDate.month}</span>
                    พ.ศ. <span class="dotted" style="min-width: 60px;">${requestDate.yearBE}</span>
                </div>
            </header>

            <main>
                <p>ข้าพเจ้า <span class="dotted" style="min-width: 200px;">${employeeTitle} ${employee.firstName} ${employee.lastName}</span>
                   ตำแหน่ง <span class="dotted" style="min-width: 200px;">${employee.position || '&nbsp;'}</span></p>
                
                <div style="display: flex; align-items: center; flex-wrap: wrap; gap: 5px; line-height: 2.8;">
                    <span>ขอลา</span>
                    <div style="display: inline-flex; align-items: center; margin-left: 20px;">
                        <div class="checkbox ${isSick ? 'checked' : ''}"></div>
                        <span>ป่วย</span>
                    </div>
                    <div style="display: inline-flex; align-items: center; margin-left: 20px;">
                        <div class="checkbox ${isPersonal ? 'checked' : ''}"></div>
                        <span>กิจส่วนตัว เนื่องจาก</span>
                        <span class="dotted" style="flex-grow: 1; min-width: 250px;">${isPersonal ? request.notes : '&nbsp;'}</span>
                    </div>
                </div>
                ${!isSick && !isPersonal ? `<p>เรื่อง: <span class="dotted" style="min-width: 400px;">${otherLeaveDetails}</span></p>` : ''}
                
                <p>โดยขอหยุดตั้งแต่วันที่ <span class="dotted" style="min-width: 40px;">${startDate.day}</span>
                   เดือน <span class="dotted">${startDate.month}</span>
                   พ.ศ. <span class="dotted" style="min-width: 60px;">${startDate.yearBE}</span></p>
                <p>ถึงวันที่ <span class="dotted" style="min-width: 40px;">${endDate.day}</span>
                   เดือน <span class="dotted">${endDate.month}</span>
                   พ.ศ. <span class="dotted" style="min-width: 60px;">${endDate.yearBE}</span></p>
                <p>มีกำหนด <span class="dotted" style="min-width: 80px;">${request.durationDays}</span> วัน</p>
                <p>ในระหว่างลางานสามารถติดต่อข้าพเจ้าได้ที่ <span class="dotted" style="min-width: 250px;">${employee.mobilePhone || '&nbsp;'}</span></p>
            </main>

            <footer style="margin-top: 40px;">
                <div style="display: flex; justify-content: flex-end; text-align: center;">
                    <div style="width: 300px;">
                        <p>ขอแสดงความนับถือ</p>
                        <p style="margin-top: 50px;">ลงชื่อ .........................................</p>
                        <p>( ${employee.firstName} ${employee.lastName} )</p>
                    </div>
                </div>

                <div style="margin-top: 40px; border: 1.5px solid #555; padding: 20px;">
                    <h2 style="font-weight: bold; text-align: center; margin-bottom: 20px;">คำสั่ง</h2>
                    <div style="display: flex; align-items: center; justify-content: center; gap: 40px; margin-bottom: 20px;">
                        <div style="display: flex; align-items: center;">
                            <div class="checkbox ${request.status === 'approved' ? 'checked' : ''}"></div>
                            <span>อนุญาต</span>
                        </div>
                        <div style="display: flex; align-items: center;">
                            <div class="checkbox ${request.status === 'rejected' ? 'checked' : ''}"></div>
                            <span>ไม่อนุญาต</span>
                        </div>
                    </div>
                    <div style="margin-top: 50px; text-align: center;">
                        <p>ลงชื่อ .........................................</p>
                        <p>( ......................................... )</p>
                        <p>ตำแหน่ง .........................................</p>
                    </div>
                </div>
            </footer>

            </div>
        </div>
    </body>
    </html>
    `;

    const printWindow = window.open('', '_blank', 'width=850,height=1100');
    if (printWindow) {
        printWindow.document.open();
        printWindow.document.write(printHtml);
        printWindow.document.close();
        printWindow.focus();
    } else {
        throw new Error("ไม่สามารถเปิดหน้าต่างใหม่ได้ กรุณาปิดการใช้งาน Pop-up Blocker");
    }
};